import React from 'react';
import { motion } from 'framer-motion';
import { Utensils, Zap, Clock, ChevronRight, Tag, Apple, Salad, Egg, Info } from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { UserProfile } from '../../lib/types';

export const MealPlanner: React.FC<{ userProfile: UserProfile | null }> = ({ userProfile }) => {
  const { t } = useLanguage();

  const meals = [
    { 
      type: 'Breakfast', 
      name: 'Oats with Local Honey & Whey', 
      cals: 450, 
      protein: 35, 
      icon: Apple, 
      isBudget: true,
      isLocal: true
    },
    { 
      type: 'Lunch', 
      name: 'Injera Fitfit with Grilled Chicken', 
      cals: 650, 
      protein: 45, 
      icon: Salad, 
      isBudget: true,
      isLocal: true
    },
    { 
      type: 'Dinner', 
      name: 'Grilled Tilapia & Brown Rice', 
      cals: 550, 
      protein: 40, 
      icon: Utensils, 
      isBudget: false,
      isLocal: true
    },
    { 
      type: 'Snack', 
      name: 'Greek Yogurt & Almonds', 
      cals: 250, 
      protein: 20, 
      icon: Egg, 
      isBudget: false,
      isLocal: false
    },
  ];

  return (
    <div className="space-y-6 pb-24 px-4 pt-6">
      <header className="relative">
        <h1 className="text-3xl font-extrabold tracking-tight text-[#d4ff00]">{t('mealPlan')}</h1>
        <p className="text-muted-foreground text-sm">Nutrition plans tailored to your {userProfile?.goal || 'fitness'} goals.</p>
      </header>

      <Card className="bg-[#d4ff00]/5 border-[#d4ff00]/20 overflow-hidden">
         <div className="h-32 relative">
            <img src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/meal-plan-hero-a1b64b3a-1775838965241.webp" className="w-full h-full object-cover" alt="Meal Prep" />
            <div className="absolute inset-0 bg-gradient-to-r from-black via-black/60 to-transparent flex flex-col justify-center px-6">
               <Badge className="w-fit mb-1 bg-[#d4ff00] text-black font-black">PRO FEATURE</Badge>
               <h3 className="text-lg font-black italic uppercase">Weekly Macro Plan</h3>
            </div>
         </div>
      </Card>

      <div className="space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2 flex items-center justify-between">
          TODAY'S SUGGESTIONS
          <Button variant="ghost" size="sm" className="text-[#d4ff00] h-6 px-2 text-[10px]">SWAP ALL</Button>
        </h3>
        
        {meals.map((meal, idx) => {
          const Icon = meal.icon;
          return (
            <motion.div
              key={meal.type}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.1 }}
            >
              <Card className="bg-secondary/20 border-white/5 hover:border-white/10 transition-all cursor-pointer group">
                <CardContent className="p-4 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-white/40 group-hover:bg-[#d4ff00]/10 group-hover:text-[#d4ff00] transition-colors">
                    <Icon size={24} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-0.5">
                       <span className="text-[10px] font-black text-[#d4ff00] uppercase tracking-tighter">{meal.type}</span>
                       {meal.isBudget && <Badge variant="outline" className="text-[8px] h-4 py-0 border-green-500/30 text-green-500 px-1">{t('budgetFriendly')}</Badge>}
                       {meal.isLocal && <Badge variant="outline" className="text-[8px] h-4 py-0 border-blue-500/30 text-blue-500 px-1">{t('localOptions')}</Badge>}
                    </div>
                    <h4 className="font-bold text-sm">{meal.name}</h4>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-[10px] text-muted-foreground font-medium">{meal.cals} kcal</span>
                      <span className="text-[10px] text-muted-foreground font-medium underline">{meal.protein}g Protein</span>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-white/20" />
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      <div className="bg-secondary/10 p-4 rounded-2xl border border-white/5 flex gap-4 items-center">
         <div className="p-2 bg-blue-500/10 rounded-xl text-blue-500">
            <Info size={20} />
         </div>
         <div>
            <p className="text-xs font-bold uppercase tracking-tight">Local Shopping List</p>
            <p className="text-[10px] text-muted-foreground">We've generated a list of local markets where you can find these ingredients at the best prices.</p>
         </div>
      </div>
    </div>
  );
};