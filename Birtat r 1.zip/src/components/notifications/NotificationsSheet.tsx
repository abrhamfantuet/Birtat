import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, X, Check, Dumbbell, Utensils, Award, TrendingUp, Zap } from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Card, CardContent } from '../ui/card';

interface NotificationsSheetProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationsSheet: React.FC<NotificationsSheetProps> = ({ isOpen, onClose }) => {
  const { t } = useLanguage();

  const notifications = [
    { 
      id: 1, 
      title: 'Workout Reminder', 
      desc: "It's time for Push A - Hypertrophy! Don't break your streak.", 
      time: '15m ago', 
      type: 'workout',
      icon: Dumbbell,
      color: 'text-[#d4ff00]'
    },
    { 
      id: 2, 
      title: 'Macro Alert', 
      desc: "You're 35g short on your protein goal for today. Consider a shake.", 
      time: '2h ago', 
      type: 'nutrition',
      icon: Utensils,
      color: 'text-blue-500'
    },
    { 
      id: 3, 
      title: 'Challenge Unlocked', 
      desc: "Mass Evolution program is now available for you!", 
      time: 'Yesterday', 
      type: 'award',
      icon: Award,
      color: 'text-purple-500'
    },
    { 
      id: 4, 
      title: 'New PB!', 
      desc: "Dawit from Community just hit a new 100kg Bench Press.", 
      time: '2 days ago', 
      type: 'social',
      icon: TrendingUp,
      color: 'text-green-500'
    },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100]"
          />
          <motion.div
            initial={{ y: '-100%' }}
            animate={{ y: 0 }}
            exit={{ y: '-100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 left-0 right-0 h-[80vh] w-full max-w-md mx-auto bg-[#050505] border-b border-white/5 z-[101] shadow-2xl flex flex-col rounded-b-[40px] overflow-hidden"
          >
            <div className="p-6 border-b border-white/5 flex items-center justify-between bg-black/40">
              <div className="flex items-center gap-3">
                 <div className="w-10 h-10 rounded-2xl bg-[#d4ff00] text-black flex items-center justify-center">
                    <Bell size={20} />
                 </div>
                 <div>
                    <h2 className="text-xl font-black uppercase italic tracking-tighter text-white">{t('notifications')}</h2>
                    <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">{t('notificationsSubtitle')}</p>
                 </div>
              </div>
              <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full hover:bg-white/5">
                <X size={20} />
              </Button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {notifications.map((n, idx) => {
                const Icon = n.icon;
                return (
                  <motion.div
                    key={n.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.1 }}
                  >
                    <Card className="bg-white/[0.03] border-white/5 hover:bg-white/[0.06] transition-all cursor-pointer group">
                      <CardContent className="p-4 flex gap-4">
                        <div className={`w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center ${n.color} flex-shrink-0 group-hover:scale-110 transition-transform`}>
                          <Icon size={22} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-start mb-0.5">
                             <h4 className="text-sm font-bold truncate pr-2">{n.title}</h4>
                             <span className="text-[9px] font-bold text-muted-foreground uppercase whitespace-nowrap">{n.time}</span>
                          </div>
                          <p className="text-[11px] text-muted-foreground leading-snug line-clamp-2">{n.desc}</p>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>

            <div className="p-6 bg-black/40 border-t border-white/5 flex gap-3">
               <Button className="flex-1 h-12 bg-white/5 hover:bg-white/10 text-white font-bold text-xs uppercase tracking-widest rounded-xl">
                  MARK ALL AS READ
               </Button>
               <Button className="h-12 w-12 bg-[#d4ff00] text-black font-bold rounded-xl flex items-center justify-center">
                  <Zap size={20} />
               </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};