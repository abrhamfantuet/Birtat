import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Dumbbell, 
  ChevronRight, 
  Scale, 
  Ruler, 
  Zap, 
  Activity,
  Sparkles,
  ShieldAlert,
  Calendar,
  Flame,
  CheckCircle2,
  BrainCircuit,
  Lock,
  ArrowRight,
  Utensils
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UserProfile } from "@/lib/types";
import { useLanguage } from "../LanguageSwitcher";

interface OnboardingProps {
  onComplete: (profile: UserProfile) => void;
}

export function Onboarding({ onComplete }: OnboardingProps) {
  const { t } = useLanguage();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [loadingText, setLoadingText] = useState("Creating your profile...");
  const [profile, setProfile] = useState<Partial<UserProfile>>({
    fitnessLevel: 'beginner',
    goal: 'fatLoss',
    weight: 75,
    height: 175,
    age: 25,
    gender: 'male',
    streak: 0,
    workoutsCompleted: 0
  });

  const nextStep = () => setStep(s => s + 1);

  const handleComplete = () => {
    setLoading(true);
    
    const messages = [
      "Initializing AI Engine...",
      "Analyzing metabolism...",
      "Calculating macros...",
      "Mapping training logic...",
      "Syncing partners...",
      "Ready!"
    ];

    let msgIndex = 0;
    const interval = setInterval(() => {
      if (msgIndex < messages.length) {
        setLoadingText(messages[msgIndex]);
        msgIndex++;
      } else {
        clearInterval(interval);
        onComplete(profile as UserProfile);
      }
    }, 1000);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050505] flex flex-col items-center justify-center p-6">
        <div className="relative w-24 h-24 mb-10">
          <motion.div
            className="absolute inset-0 border-2 border-[#d4ff00]/20 rounded-full"
            animate={{ scale: [1, 1.2, 1], opacity: [0.2, 0.5, 0.2] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
          <motion.div
            className="absolute inset-0 border-t-2 border-r-2 border-[#d4ff00] rounded-full"
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <BrainCircuit className="w-10 h-10 text-[#d4ff00]" />
          </div>
        </div>
        <motion.p
          key={loadingText}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-xl font-black italic uppercase tracking-tight text-white text-center"
        >
          {loadingText}
        </motion.p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] text-white p-6 pt-12 pb-32">
      <div className="max-w-md mx-auto">
        {/* Slim Progress Bar */}
        <div className="flex gap-1 mb-16">
          {[1, 2, 3, 4].map(i => (
            <div 
              key={i} 
              className={`h-1 flex-1 rounded-full transition-all duration-500 ${
                i <= step ? 'bg-[#d4ff00]' : 'bg-white/10'
              }`} 
            />
          ))}
        </div>

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              className="space-y-10"
            >
              <div className="space-y-3">
                <h1 className="text-4xl font-black italic uppercase tracking-tighter leading-tight">
                  Choose Your <br /> <span className="text-[#d4ff00]">Goal</span>
                </h1>
                <p className="text-white/40 font-bold uppercase text-[9px] tracking-widest">
                   Everything will be built around this.
                </p>
              </div>

              <div className="grid gap-4">
                {[
                  { id: 'fatLoss', label: 'Burn Fat', icon: Flame, desc: 'Maximum definition' },
                  { id: 'hypertrophy', label: 'Build Muscle', icon: Dumbbell, desc: 'Size and strength' },
                  { id: 'discipline', label: 'Mental Grit', icon: ShieldAlert, desc: 'Consistency focus' },
                ].map((goal) => (
                  <button
                    key={goal.id}
                    onClick={() => {
                      setProfile({ ...profile, goal: goal.id as UserProfile['goal'] });
                      nextStep();
                    }}
                    className={`group relative flex items-center gap-5 p-6 rounded-[2rem] border-2 transition-all ${
                      profile.goal === goal.id 
                        ? 'bg-[#d4ff00] border-[#d4ff00] text-black' 
                        : 'bg-white/5 border-white/5 hover:border-white/10'
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${
                      profile.goal === goal.id ? 'bg-black/10' : 'bg-white/5'
                    }`}>
                      <goal.icon className="w-6 h-6" />
                    </div>
                    <div className="text-left flex-1">
                      <p className="text-lg font-black uppercase italic leading-none mb-1">{goal.label}</p>
                      <p className={`text-[9px] font-bold uppercase tracking-wider ${
                        profile.goal === goal.id ? 'text-black/50' : 'text-white/30'
                      }`}>{goal.desc}</p>
                    </div>
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-10"
            >
              <div className="space-y-3">
                <h1 className="text-4xl font-black italic uppercase tracking-tighter">
                  The <span className="text-[#d4ff00]">Baseline</span>
                </h1>
                <p className="text-white/40 font-bold uppercase text-[9px] tracking-widest">Essential body stats.</p>
              </div>

              <div className="space-y-8">
                <div className="grid grid-cols-2 gap-4">
                  {['male', 'female'].map(g => (
                    <button
                      key={g}
                      onClick={() => setProfile({ ...profile, gender: g as 'male' | 'female' })}
                      className={`py-5 rounded-2xl border-2 font-black uppercase italic transition-all ${
                        profile.gender === g ? 'bg-[#d4ff00] border-[#d4ff00] text-black' : 'bg-white/5 border-white/5'
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <Label className="text-[9px] font-bold uppercase tracking-widest text-white/30">Weight (kg)</Label>
                    <Input
                      type="number"
                      className="bg-white/5 border-white/10 h-14 text-lg font-black italic rounded-2xl focus:border-[#d4ff00]/50"
                      value={profile.weight}
                      onChange={(e) => setProfile({ ...profile, weight: Number(e.target.value) })}
                    />
                  </div>
                  <div className="space-y-3">
                    <Label className="text-[9px] font-bold uppercase tracking-widest text-white/30">Height (cm)</Label>
                    <Input
                      type="number"
                      className="bg-white/5 border-white/10 h-14 text-lg font-black italic rounded-2xl focus:border-[#d4ff00]/50"
                      value={profile.height}
                      onChange={(e) => setProfile({ ...profile, height: Number(e.target.value) })}
                    />
                  </div>
                </div>
              </div>

              <Button 
                onClick={nextStep}
                className="w-full bg-[#d4ff00] text-black hover:bg-[#b8de00] h-16 text-lg font-black uppercase italic rounded-2xl"
              >
                Continue <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-10"
            >
              <div className="space-y-3">
                <h1 className="text-4xl font-black italic uppercase tracking-tighter">
                  Your <span className="text-[#d4ff00]">Level</span>
                </h1>
                <p className="text-white/40 font-bold uppercase text-[9px] tracking-widest">Scaling your volume.</p>
              </div>

              <div className="grid gap-4">
                {[
                  { id: 'beginner', label: 'Starter', desc: '0-1 years training' },
                  { id: 'intermediate', label: 'Focused', desc: '1-3 years training' },
                  { id: 'advanced', label: 'Pro', desc: '4+ years training' },
                ].map((level) => (
                  <button
                    key={level.id}
                    onClick={() => {
                      setProfile({ ...profile, fitnessLevel: level.id as UserProfile['fitnessLevel'] });
                      nextStep();
                    }}
                    className={`relative flex items-center gap-4 p-6 rounded-[2rem] border-2 transition-all ${
                      profile.fitnessLevel === level.id 
                        ? 'bg-[#d4ff00] border-[#d4ff00] text-black scale-[1.02]' 
                        : 'bg-white/5 border-white/5 hover:border-white/10'
                    }`}
                  >
                    <div className="flex-1 text-left">
                      <p className="text-xl font-black uppercase italic leading-none">{level.label}</p>
                      <p className={`text-[9px] font-bold uppercase tracking-wider mt-1 ${
                        profile.fitnessLevel === level.id ? 'text-black/50' : 'text-white/30'
                      }`}>{level.desc}</p>
                    </div>
                    {profile.fitnessLevel === level.id && <CheckCircle2 className="w-5 h-5" />}
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-8"
            >
              <div className="text-center space-y-3 py-6">
                <h1 className="text-5xl font-black italic uppercase tracking-tighter">
                    Ready to <br /> <span className="text-[#d4ff00]">Deploy.</span>
                </h1>
                <p className="text-white/40 font-bold uppercase text-[9px] tracking-widest">
                    Personalized plan calculated.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-4">
                <div className="bg-white/5 border border-white/10 p-6 rounded-[2rem] flex justify-between items-center">
                    <div>
                      <p className="text-[9px] font-bold text-white/30 uppercase tracking-widest">Daily Macros</p>
                      <p className="text-2xl font-black italic">{profile.goal === 'fatLoss' ? '2,450' : '3,200'} kcal</p>
                    </div>
                    <Utensils className="w-8 h-8 text-[#d4ff00]/40" />
                </div>

                <div className="bg-white/5 border border-white/10 p-6 rounded-[2rem] flex justify-between items-center">
                    <div>
                      <p className="text-[9px] font-bold text-white/30 uppercase tracking-widest">Split Type</p>
                      <p className="text-2xl font-black italic">{profile.fitnessLevel === 'advanced' ? 'PPL' : 'Full Body'}</p>
                    </div>
                    <Dumbbell className="w-8 h-8 text-[#d4ff00]/40" />
                </div>
              </div>

              <Button 
                onClick={handleComplete}
                className="w-full bg-[#d4ff00] text-black hover:scale-105 h-20 text-xl font-black uppercase italic mt-4 rounded-3xl transition-all shadow-xl shadow-[#d4ff00]/10"
              >
                Generate My Plan <Sparkles className="ml-3 w-5 h-5" />
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}