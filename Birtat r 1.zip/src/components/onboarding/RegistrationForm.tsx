import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Phone, Mail, Lock, ChevronRight, UserPlus, Shield, CheckCircle2, Key, QrCode } from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { toast } from 'sonner';

interface RegistrationFormProps {
  onSuccess: (data: { email: string; phoneNumber: string; password?: string }) => void;
}

type Step = 'initial' | 'verification' | '2fa';

export const RegistrationForm: React.FC<RegistrationFormProps> = ({ onSuccess }) => {
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    email: '',
    phoneNumber: '',
    password: ''
  });
  const [step, setStep] = useState<Step>('initial');
  const [isLoading, setIsLoading] = useState(false);
  const [verificationCodes, setVerificationCodes] = useState({ email: '', phone: '' });
  const [totpCode, setTotpCode] = useState('');

  const validatePassword = (pass: string) => {
    // 8 digits + strong (number, upper, lower, special)
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/;
    return regex.test(pass);
  };

  const submitToGoogleSheets = async (data: any) => {
    try {
      const payload = {
        timestamp: new Date().toISOString(),
        email: data.email,
        phone: data.phoneNumber,
        status: 'registered_with_2fa'
      };
      
      console.log('Sending to Google Sheets:', payload);
      return true;
    } catch (e) {
      console.error('Sheets Error', e);
      return false;
    }
  };

  const handleInitialSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.phoneNumber) return toast.error(t('phoneRequired'));
    if (!formData.email) return toast.error(t('emailRequired'));
    if (!validatePassword(formData.password)) {
      return toast.error("Password must be at least 8 characters with at least one uppercase, one lowercase, one number and one special character.");
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setStep('verification');
      toast.info("Verification codes sent to your phone and email.");
    }, 1000);
  };

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (verificationCodes.email.length < 4 || verificationCodes.phone.length < 4) {
      return toast.error("Please enter the 4-digit verification codes.");
    }
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setStep('2fa');
    }, 1000);
  };

  const handle2FASetup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (totpCode.length < 6) return toast.error("Enter the 6-digit code from Google Authenticator.");
    
    setIsLoading(true);
    await submitToGoogleSheets(formData);
    setTimeout(() => {
      setIsLoading(false);
      toast.success(t('registrationSuccess'));
      onSuccess(formData);
    }, 1500);
  };

  return (
    <div className="min-h-screen relative flex flex-col justify-center p-6 bg-[#050505]">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/welcome-bg-04bf2573-1775587043861.webp" 
          className="w-full h-full object-cover opacity-30" 
          alt="Welcome" 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-[#050505]/80 to-transparent" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 w-full max-w-sm mx-auto space-y-8"
      >
        <div className="text-center space-y-2">
          <div className="w-16 h-16 bg-[#d4ff00] rounded-2xl flex items-center justify-center mx-auto mb-6 rotate-3 shadow-[0_0_30px_rgba(212,255,0,0.3)]">
            <UserPlus className="text-black" size={32} />
          </div>
          <h1 className="text-4xl font-black tracking-tighter text-white uppercase italic">
            {step === 'initial' ? t('welcomeTitle') : step === 'verification' ? 'Verify Account' : 'Security Setup'}
          </h1>
          <p className="text-white/60 text-xs font-bold uppercase tracking-widest">
            {step === 'initial' ? t('welcomeSubtitle') : step === 'verification' ? 'Enter codes sent to your devices' : 'Google Authenticator 2FA'}
          </p>
        </div>

        <AnimatePresence mode="wait">
          {step === 'initial' && (
            <motion.form 
              key="initial"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleInitialSubmit} 
              className="space-y-4"
            >
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-[10px] font-black text-white/40 uppercase tracking-widest pl-1">{t('phoneNumber')}</Label>
                  <div className="relative group">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40 group-focus-within:text-[#d4ff00] transition-colors" size={18} />
                    <Input 
                      type="tel"
                      placeholder="+251 9..."
                      className="bg-white/5 border-white/10 h-14 pl-12 rounded-2xl focus:border-[#d4ff00]/50 focus:ring-1 focus:ring-[#d4ff00]/50 transition-all font-bold"
                      value={formData.phoneNumber}
                      onChange={(e) => setFormData({...formData, phoneNumber: e.target.value})}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-[10px] font-black text-white/40 uppercase tracking-widest pl-1">{t('email')}</Label>
                  <div className="relative group">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40 group-focus-within:text-[#d4ff00] transition-colors" size={18} />
                    <Input 
                      type="email"
                      placeholder="alex@example.com"
                      className="bg-white/5 border-white/10 h-14 pl-12 rounded-2xl focus:border-[#d4ff00]/50 focus:ring-1 focus:ring-[#d4ff00]/50 transition-all font-bold"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-[10px] font-black text-white/40 uppercase tracking-widest pl-1">{t('password')} (Min 8 Chars, Mixed Case & Symbol)</Label>
                  <div className="relative group">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40 group-focus-within:text-[#d4ff00] transition-colors" size={18} />
                    <Input 
                      type="password"
                      placeholder="\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
                      className="bg-white/5 border-white/10 h-14 pl-12 rounded-2xl focus:border-[#d4ff00]/50 focus:ring-1 focus:ring-[#d4ff00]/50 transition-all font-bold"
                      value={formData.password}
                      onChange={(e) => setFormData({...formData, password: e.target.value})}
                    />
                  </div>
                </div>
              </div>

              <Button 
                type="submit"
                disabled={false}
                className="w-full h-14 bg-[#d4ff00] hover:bg-[#c4eb00] text-black font-black rounded-2xl transition-all shadow-lg shadow-[#d4ff00]/20 flex items-center justify-center gap-2 group mt-2"
              >
                {isLoading ? <div className="w-6 h-6 border-4 border-black/30 border-t-black rounded-full animate-spin" /> : <>{t('register')} <ChevronRight size={20} /></>}
              </Button>
            </motion.form>
          )}

          {step === 'verification' && (
            <motion.form 
              key="verify"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleVerify} 
              className="space-y-6"
            >
              <div className="space-y-4">
                <div className="p-4 bg-white/5 border border-white/10 rounded-2xl flex items-center gap-3">
                  <Mail className="text-[#d4ff00]" size={20} />
                  <div className="flex-1">
                    <Label className="text-[9px] font-black text-white/40 uppercase">Email Code</Label>
                    <Input 
                      placeholder="1234"
                      className="bg-transparent border-none h-8 p-0 text-xl font-black tracking-[0.5em] focus:ring-0"
                      maxLength={4}
                      value={verificationCodes.email}
                      onChange={(e) => setVerificationCodes({...verificationCodes, email: e.target.value})}
                    />
                  </div>
                </div>
                <div className="p-4 bg-white/5 border border-white/10 rounded-2xl flex items-center gap-3">
                  <Phone className="text-[#d4ff00]" size={20} />
                  <div className="flex-1">
                    <Label className="text-[9px] font-black text-white/40 uppercase">SMS Code</Label>
                    <Input 
                      placeholder="1234"
                      className="bg-transparent border-none h-8 p-0 text-xl font-black tracking-[0.5em] focus:ring-0"
                      maxLength={4}
                      value={verificationCodes.phone}
                      onChange={(e) => setVerificationCodes({...verificationCodes, phone: e.target.value})}
                    />
                  </div>
                </div>
              </div>
              <Button type="submit" disabled={false} className="w-full h-14 bg-[#d4ff00] text-black font-black rounded-2xl">VERIFY CODES</Button>
            </motion.form>
          )}

          {step === '2fa' && (
            <motion.form 
              key="2fa"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handle2FASetup} 
              className="space-y-6"
            >
              <div className="p-6 bg-white/5 border border-white/10 rounded-3xl text-center space-y-4">
                 <div className="w-32 h-32 bg-white rounded-xl mx-auto flex items-center justify-center p-2">
                    <QrCode className="text-black w-full h-full" />
                 </div>
                 <p className="text-[10px] text-white/40 uppercase font-black">Scan with Google Authenticator</p>
                 <div className="relative">
                    <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" size={18} />
                    <Input 
                      placeholder="Enter 6-digit code"
                      className="bg-white/5 border-white/10 h-14 pl-12 rounded-2xl text-center font-black tracking-[0.3em]"
                      maxLength={6}
                      value={totpCode}
                      onChange={(e) => setTotpCode(e.target.value)}
                    />
                 </div>
              </div>
              <Button type="submit" disabled={false} className="w-full h-14 bg-[#d4ff00] text-black font-black rounded-2xl">COMPLETE SECURE SETUP</Button>
            </motion.form>
          )}
        </AnimatePresence>

        <div className="flex items-start gap-3 p-4 bg-secondary/10 rounded-2xl border border-white/5">
           <Shield size={16} className="text-[#d4ff00] mt-0.5" />
           <p className="text-[9px] text-muted-foreground leading-tight uppercase font-bold">
              {t('privacyDisclaimer')}
           </p>
        </div>

        <div className="text-center">
          <p className="text-white/40 text-[10px] font-black uppercase tracking-tighter">
            {t('alreadyHaveAccount')} <span className="text-[#d4ff00] cursor-pointer" onClick={() => (window as any).location.reload()}>{t('login')}</span>
          </p>
        </div>
      </motion.div>
    </div>
  );
};