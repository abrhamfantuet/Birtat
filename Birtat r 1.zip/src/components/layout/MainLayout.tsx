import React, { useState } from "react";
import { Sidebar } from "./Sidebar";
import { Navbar } from "./Navbar";
import { UserProfile } from "../../lib/types";
import { 
  Sheet, 
  SheetContent, 
  SheetTrigger 
} from "../ui/sheet";

interface MainLayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  userProfile: UserProfile | null;
  onOpenSettings: (tab?: string) => void;
  onLogout: () => void;
  onOpenNotifications: () => void;
}

export function MainLayout({ 
  children, 
  activeTab, 
  setActiveTab, 
  userProfile, 
  onOpenSettings,
  onLogout,
  onOpenNotifications
}: MainLayoutProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-[#020202] text-white">
      {/* Desktop Sidebar */}
      <div className="hidden md:block w-72 h-screen fixed left-0 top-0 z-40">
        <Sidebar 
          activeTab={activeTab} 
          setActiveTab={setActiveTab} 
          userProfile={userProfile} 
          onOpenSettings={onOpenSettings} 
        />
      </div>

      {/* Mobile Sidebar (Sheet) */}
      <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
        <SheetContent side="left" className="p-0 w-72 bg-[#050505] border-r border-white/5">
          <Sidebar 
            activeTab={activeTab} 
            setActiveTab={setActiveTab} 
            userProfile={userProfile} 
            onOpenSettings={onOpenSettings} 
            onClose={() => setIsMobileMenuOpen(false)}
          />
        </SheetContent>
      </Sheet>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col md:pl-72 relative min-h-screen">
        {/* Top Navbar */}
        <Navbar 
          userProfile={userProfile} 
          onLogout={onLogout} 
          onOpenNotifications={onOpenNotifications}
          onOpenSettings={onOpenSettings}
          showTabs={false}
          onMenuClick={() => setIsMobileMenuOpen(true)}
        />
        
        {/* Page Content */}
        <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-6 md:px-8 lg:px-10 pb-10">
          {children}
        </main>
      </div>
    </div>
  );
}