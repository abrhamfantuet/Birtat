import React from 'react';
import { motion } from 'framer-motion';
import { 
  User, 
  Settings, 
  Bell, 
  Menu
} from 'lucide-react';
import { useLanguage, LanguageSwitcher } from '../LanguageSwitcher';
import { Button } from '../ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { UserProfile } from '../../lib/types';
import { cn } from '../../lib/utils';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../ui/tooltip';

interface NavbarProps {
  userProfile: UserProfile | null;
  onLogout: () => void;
  onOpenNotifications: () => void;
  onOpenSettings: (tab?: string) => void;
  activeTab?: string;
  setActiveTab?: (tab: string) => void;
  showTabs?: boolean;
  onMenuClick?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  userProfile, 
  onOpenNotifications, 
  onOpenSettings,
  showTabs = false,
  onMenuClick
}) => {
  const { t } = useLanguage();

  return (
    <TooltipProvider>
      <nav className="sticky top-0 z-[60] w-full bg-[#020202]/80 backdrop-blur-xl border-b border-white/5">
        <div className={cn(
          "w-full px-4 h-16 flex items-center justify-between",
          showTabs && "max-w-7xl mx-auto"
        )}>
          {/* Mobile Menu Trigger & Logo */}
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-white/60 hover:text-white"
              onClick={onMenuClick}
            >
              <Menu size={24} />
            </Button>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-2 cursor-pointer"
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            >
              <div className="w-8 h-8 bg-[#d4ff00] rounded-lg flex items-center justify-center rotate-3 shadow-[0_0_20px_rgba(212,255,0,0.2)]">
                <span className="text-black font-black text-xs">B</span>
              </div>
              <span className="text-lg font-black tracking-tighter text-white italic">BIRTAT</span>
            </motion.div>
          </div>

          {/* Top Right Actions: Settings Hub & Profile */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Language Switcher */}
            <Tooltip>
              <TooltipTrigger asChild>
                <div>
                  <LanguageSwitcher />
                </div>
              </TooltipTrigger>
              <TooltipContent className="bg-[#0a0a0a] border-white/10 text-white font-bold text-[10px] uppercase tracking-widest">
                Language
              </TooltipContent>
            </Tooltip>

            {/* Notifications */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  onClick={onOpenNotifications}
                  variant="ghost" 
                  size="icon" 
                  className="relative text-white/60 hover:text-white rounded-full hover:bg-white/5 h-10 w-10"
                >
                  <Bell size={20} />
                  <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-[#d4ff00] rounded-full border-2 border-[#050505]"></span>
                </Button>
              </TooltipTrigger>
              <TooltipContent className="bg-[#0a0a0a] border-white/10 text-white font-bold text-[10px] uppercase tracking-widest">
                {t('notifications')}
              </TooltipContent>
            </Tooltip>

            {/* Settings Hub */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  onClick={() => onOpenSettings('account')}
                  variant="ghost" 
                  size="icon" 
                  className="text-white/60 hover:text-white rounded-full hover:bg-white/5 h-10 w-10"
                >
                  <Settings size={20} />
                </Button>
              </TooltipTrigger>
              <TooltipContent className="bg-[#0a0a0a] border-white/10 text-white font-bold text-[10px] uppercase tracking-widest">
                {t('settings')}
              </TooltipContent>
            </Tooltip>

            {/* Profile */}
            <Tooltip>
              <TooltipTrigger asChild>
                <button 
                  onClick={() => onOpenSettings('profile')}
                  className="flex items-center gap-2 pl-2 pr-1 py-1 rounded-full border border-white/5 bg-white/[0.03] hover:bg-white/[0.08] hover:border-[#d4ff00]/30 transition-all group"
                >
                  <span className="hidden lg:inline text-[10px] font-black uppercase tracking-wider text-white/70 group-hover:text-white mr-1">
                    {userProfile?.email?.split('@')[0] || 'Athlete'}
                  </span>
                  <Avatar className="w-8 h-8 border border-white/10 group-hover:border-[#d4ff00]/50 transition-colors">
                    <AvatarImage src={userProfile?.selfieUrl || ""} />
                    <AvatarFallback className="bg-[#d4ff00] text-black font-black text-xs">
                      {userProfile?.email?.[0]?.toUpperCase() || <User size={14} />}
                    </AvatarFallback>
                  </Avatar>
                </button>
              </TooltipTrigger>
              <TooltipContent className="bg-[#0a0a0a] border-white/10 text-white font-bold text-[10px] uppercase tracking-widest">
                {t('profile')}
              </TooltipContent>
            </Tooltip>
          </div>
        </div>
      </nav>
    </TooltipProvider>
  );
};