import { 
  Dumbbell, 
  Utensils, 
  Users, 
  ShoppingBag, 
  Zap
} from "lucide-react";
import { useLanguage } from "../LanguageSwitcher";

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export function BottomNav({ activeTab, setActiveTab }: BottomNavProps) {
  const { t } = useLanguage();

  const tabs = [
    { id: "workout", icon: Dumbbell, label: t('workout') },
    { id: "nutrition", icon: Utensils, label: t('nutrition') },
    { id: "community", icon: Users, label: t('community') },
    { id: "shop", icon: ShoppingBag, label: t('shop') },
    { id: "coach", icon: Zap, label: t('coachingHub') },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 px-4 pb-6 pointer-events-none md:hidden">
      <div className="max-w-md mx-auto bg-black/80 backdrop-blur-3xl border border-white/10 rounded-3xl p-2 flex items-center justify-between shadow-[0_0_50px_rgba(0,0,0,0.5)] pointer-events-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`relative flex-1 flex flex-col items-center justify-center transition-all py-3 ${
              activeTab === tab.id 
                ? "text-[#d4ff00]" 
                : "text-white/40 hover:text-white/60"
            }`}
          >
            <tab.icon className={`w-5 h-5 mb-1.5 transition-all duration-300 ${activeTab === tab.id ? 'scale-110' : 'scale-100'}`} />
            <span className={`text-[8px] font-black uppercase tracking-[0.1em] transition-all duration-300 ${activeTab === tab.id ? 'opacity-100' : 'opacity-40'}`}>
              {tab.label}
            </span>
            {activeTab === tab.id && (
              <div className="absolute -bottom-1 w-1 h-1 rounded-full bg-[#d4ff00] shadow-[0_0_15px_rgba(212,255,0,0.8)]" />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}