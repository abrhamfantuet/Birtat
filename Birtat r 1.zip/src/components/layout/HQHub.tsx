import { motion } from "framer-motion";
import { 
  TrendingUp, 
  Trophy, 
  MessageSquare, 
  CreditCard, 
  Shield, 
  Settings, 
  ChevronRight, 
  Flame,
  Activity,
  Target,
  LogOut
} from "lucide-react";
import { UserProfile } from "../../lib/types";

interface HQHubProps {
  userProfile: UserProfile | null;
  setActiveTab: (tab: string) => void;
}

export function HQHub({ userProfile, setActiveTab }: HQHubProps) {
  const hubItems = [
    { 
      id: "analytics", 
      label: "Progress", 
      description: "Biometrics & Logs", 
      icon: TrendingUp, 
      color: "text-blue-400",
      action: () => setActiveTab("hq") // In a real app, this might go to a sub-page
    },
    { 
      id: "programs", 
      label: "Programs", 
      description: "Locked Training", 
      icon: Trophy, 
      color: "text-[#d4ff00]",
      action: () => {} 
    },
    { 
      id: "coach", 
      label: "AI Coach", 
      description: "24/7 Intelligence", 
      icon: MessageSquare, 
      color: "text-purple-400",
      action: () => {} 
    },
    { 
      id: "billing", 
      label: "Pro Access", 
      description: "Manage Plan", 
      icon: CreditCard, 
      color: "text-orange-400",
      action: () => {} 
    },
  ];

  return (
    <div className="space-y-10 max-w-4xl mx-auto">
      {/* HQ Header */}
      <div className="relative h-64 rounded-[3rem] overflow-hidden group">
        <img 
          src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/hq-dashboard-bg-ff3f5436-1775839575793.webp"
          alt="HQ Background"
          className="absolute inset-0 w-full h-full object-cover grayscale opacity-40 group-hover:scale-105 transition-transform duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent" />
        <div className="absolute inset-0 p-10 flex flex-col justify-end">
           <p className="text-[10px] font-black uppercase tracking-[0.3em] text-[#d4ff00] mb-2">Central Command</p>
           <h1 className="text-5xl font-black italic uppercase tracking-tighter">OPERATOR <span className="text-[#d4ff00]">HQ.</span></h1>
        </div>
      </div>

      {/* Core Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Current Streak", value: `${userProfile?.streak || 0}d`, icon: Flame, color: "#d4ff00" },
          { label: "Daily Average", value: "4.2k", icon: Activity, color: "#fff" },
          { label: "Focus", value: "Elite", icon: Target, color: "#d4ff00" },
          { label: "Security", value: "Active", icon: Shield, color: "#fff" },
        ].map((stat, i) => (
          <div key={i} className="bg-white/[0.03] border border-white/5 p-6 rounded-[2rem] flex flex-col items-center text-center">
            <stat.icon className="w-5 h-5 mb-3" style={{ color: stat.color }} />
            <p className="text-2xl font-black italic mb-1">{stat.value}</p>
            <p className="text-[8px] font-bold uppercase tracking-widest text-white/30">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Hub Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {hubItems.map((item) => (
          <motion.button
            key={item.id}
            whileHover={{ y: -4 }}
            onClick={item.action}
            className="flex items-center gap-6 bg-[#0a0a0a] border border-white/5 p-8 rounded-[2.5rem] text-left hover:bg-white/[0.02] transition-all group"
          >
            <div className={`w-14 h-14 rounded-2xl bg-white/[0.03] flex items-center justify-center border border-white/5 group-hover:border-[#d4ff00]/30 transition-colors`}>
              <item.icon className={`w-6 h-6 ${item.color}`} />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-black uppercase italic">{item.label}</h3>
              <p className="text-xs font-bold text-white/30 uppercase tracking-wide">{item.description}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-white/10 group-hover:text-[#d4ff00] transition-colors" />
          </motion.button>
        ))}
      </div>

      {/* Bottom Quick Settings */}
      <div className="pt-10 flex flex-wrap gap-4">
        <button className="bg-white/5 border border-white/5 px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest italic hover:bg-white/10 transition-all flex items-center gap-2">
          <Settings className="w-3 h-3" /> Account Settings
        </button>
        <button className="bg-white/5 border border-white/5 px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest italic hover:bg-white/10 transition-all flex items-center gap-2">
          <LogOut className="w-3 h-3" /> Sign Out
        </button>
      </div>
    </div>
  );
}