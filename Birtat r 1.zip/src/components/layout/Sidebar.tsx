import { 
  Dumbbell, 
  Utensils, 
  Users, 
  ShoppingBag, 
  Zap,
  Settings,
  ChevronRight,
  User
} from "lucide-react";
import { motion } from "framer-motion";
import { useLanguage } from "../LanguageSwitcher";
import { UserProfile } from "../../lib/types";
import { cn } from "../../lib/utils";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  userProfile: UserProfile | null;
  onOpenSettings: (tab?: string) => void;
  className?: string;
  onClose?: () => void; // Optional callback for mobile closing
}

export function Sidebar({ 
  activeTab, 
  setActiveTab, 
  userProfile, 
  onOpenSettings,
  className,
  onClose
}: SidebarProps) {
  const { t } = useLanguage();

  const tabs = [
    { id: "workout", icon: Dumbbell, label: t('workout') },
    { id: "nutrition", icon: Utensils, label: t('nutrition') },
    { id: "community", icon: Users, label: t('community') },
    { id: "shop", icon: ShoppingBag, label: t('shop') },
    { id: "coach", icon: Zap, label: t('coachingHub') },
  ];

  const handleTabClick = (tabId: string) => {
    setActiveTab(tabId);
    if (onClose) onClose();
  };

  return (
    <aside className={cn("flex flex-col w-full h-full bg-[#050505] border-r border-white/5", className)}>
      <div className="p-8 flex flex-col h-full">
        {/* Logo */}
        <div className="flex items-center gap-3 mb-12">
          <div className="w-10 h-10 bg-[#d4ff00] rounded-xl flex items-center justify-center rotate-3 shadow-[0_0_20px_rgba(212,255,0,0.2)]">
            <span className="text-black font-black text-sm italic">B</span>
          </div>
          <span className="text-2xl font-black tracking-tighter uppercase italic text-white">BIRTAT</span>
        </div>

        {/* Navigation */}
        <nav className="space-y-2 flex-1 overflow-y-auto no-scrollbar">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => handleTabClick(tab.id)}
              className={`w-full group relative flex items-center gap-4 p-4 rounded-2xl transition-all ${
                activeTab === tab.id 
                  ? "bg-white/[0.04] text-white shadow-[0_0_20px_rgba(212,255,0,0.05)]" 
                  : "text-white/40 hover:text-white/70 hover:bg-white/[0.02]"
              }`}
            >
              <div className={`p-2 rounded-lg transition-all duration-300 ${
                activeTab === tab.id ? "bg-[#d4ff00] text-black" : "bg-white/5 text-white/40 group-hover:text-white"
              }`}>
                <tab.icon className="w-5 h-5" />
              </div>
              <p className="text-[10px] font-black uppercase tracking-[0.15em] italic">{tab.label}</p>
              {activeTab === tab.id && (
                <motion.div 
                  layoutId="activeTabSidebar"
                  className="absolute left-0 w-1 h-8 rounded-r-full bg-[#d4ff00] shadow-[0_0_15px_#d4ff00]" 
                />
              )}
            </button>
          ))}
        </nav>

        {/* Footer Actions */}
        <div className="mt-auto pt-6 space-y-4">
          <button 
            onClick={() => {
              onOpenSettings('account');
              if (onClose) onClose();
            }}
            className="w-full flex items-center gap-4 p-4 rounded-2xl text-white/40 hover:text-white/80 hover:bg-white/[0.02] transition-all group"
          >
            <div className="p-2 bg-white/5 rounded-lg group-hover:bg-[#d4ff00]/10 group-hover:text-[#d4ff00] transition-colors">
              <Settings className="w-5 h-5" />
            </div>
            <p className="text-[10px] font-black uppercase tracking-[0.15em] italic">{t('settings')}</p>
          </button>
          
          <button 
            onClick={() => {
              onOpenSettings('profile');
              if (onClose) onClose();
            }}
            className="flex items-center gap-4 bg-white/[0.03] p-4 rounded-3xl border border-white/5 hover:border-[#d4ff00]/30 transition-all cursor-pointer group w-full"
          >
            <div className="w-10 h-10 rounded-full bg-[#d4ff00]/20 flex items-center justify-center border border-[#d4ff00]/30 overflow-hidden ring-2 ring-transparent group-hover:ring-[#d4ff00]/20 transition-all flex-shrink-0">
               <img 
                 src={userProfile?.selfieUrl || "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix"}
                 alt="User" 
                 className="w-full h-full object-cover"
               />
            </div>
            <div className="flex-1 text-left">
               <p className="text-[10px] font-black uppercase italic text-white truncate max-w-[100px]">
                 {userProfile?.email?.split('@')[0] || 'Athlete'}
               </p>
               <p className="text-[8px] font-bold uppercase text-[#d4ff00] tracking-widest">
                 {userProfile?.isPro ? 'ELITE PRO' : 'FREE ACCOUNT'}
               </p>
            </div>
            <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-[#d4ff00] transition-colors flex-shrink-0" />
          </button>
        </div>
      </div>
    </aside>
  );
}