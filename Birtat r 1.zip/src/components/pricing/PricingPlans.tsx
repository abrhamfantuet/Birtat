import React from 'react';
import { motion } from 'framer-motion';
import { Check, Zap, Shield, X } from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { toast } from 'sonner';

interface PricingPlansProps {
  onClose?: () => void;
  onSelect?: (plan: any) => void;
}

export const PricingPlans: React.FC<PricingPlansProps> = ({ onClose, onSelect }) => {
  const { t } = useLanguage();

  const handleSubscribe = (plan: any) => {
    if (onSelect) {
      onSelect(plan);
    } else {
      toast.success(`Redirecting to payment gateway for ${plan.name} plan...`);
    }
  };

  const plans = [
    {
      name: 'Starter Pro',
      price: '2,500',
      description: 'The foundation for your transformation.',
      features: ['Daily workout log', 'Basic AI Coach', 'Community Access', 'Yearly Support'],
      color: 'bg-secondary/20',
      button: 'Activate Starter',
      isPro: true
    },
    {
      name: 'Athlete Elite',
      price: '5,000',
      description: 'The ultimate toolkit for serious gains.',
      features: ['AI Personalized Plans', '3D Body Model tracking', 'AI Food Analysis', 'Premium Marketplace pricing', '1-on-1 AI Guidance'],
      color: 'bg-gradient-to-br from-[#d4ff00]/20 to-secondary/30',
      borderColor: 'border-[#d4ff00]/50',
      button: 'Go Athlete Elite',
      isPro: true,
      popular: true
    },
    {
      name: 'Coach Direct',
      price: '10,000',
      description: 'Work directly with certified experts.',
      features: ['Everything in Elite', 'Human Certified Coach', 'Custom Meal Prep lists', 'Video Call check-ins', 'Priority 24/7 Support'],
      color: 'bg-secondary/40',
      button: 'Join Coach Direct',
      isPro: true
    },
    {
      name: 'Titan Corporate',
      price: '50,000',
      description: 'The complete ecosystem for teams.',
      features: ['Full Team Access', 'Custom Fitness Concierge', 'Corporate Challenges', 'Exclusive Titan Events', 'White-glove Onboarding'],
      color: 'bg-white/5',
      button: 'Get Titan Status',
      isPro: true
    }
  ];

  return (
    <div className="min-h-screen bg-[#050505] py-12 px-4 pb-32">
      <header className="text-center space-y-4 mb-12 relative">
        {onClose && (
          <button onClick={onClose} className="absolute -top-4 right-0 p-2 text-white/40 hover:text-white">
            <X size={24} />
          </button>
        )}
        <div className="w-16 h-16 bg-[#d4ff00] rounded-2xl flex items-center justify-center mx-auto rotate-6 shadow-[0_0_30px_rgba(212,255,0,0.3)] mb-4">
           <Zap className="text-black" size={32} />
        </div>
        <h1 className="text-4xl font-black uppercase italic tracking-tighter text-white">YEARLY PLANS</h1>
        <p className="text-white/60 text-xs font-bold uppercase tracking-widest max-w-[280px] mx-auto">Activate your transformation in Birr (ETB).</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
        {plans.map((plan, idx) => (
          <motion.div
            key={plan.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
          >
            <Card className={`h-full overflow-hidden border-white/5 ${plan.color} ${plan.borderColor} relative flex flex-col`}>
              {plan.popular && (
                <div className="absolute top-4 right-4">
                  <Badge className="bg-[#d4ff00] text-black border-none font-black">BEST VALUE</Badge>
                </div>
              )}
              <CardHeader className="p-6 pb-2">
                <CardTitle className="text-2xl font-black italic uppercase tracking-tighter">{plan.name}</CardTitle>
                <div className="flex items-baseline gap-1 mt-2">
                   <span className="text-3xl font-black text-white">{plan.price}</span>
                   <span className="text-xs font-bold text-white/40 uppercase">{t('currency')} / YEAR</span>
                </div>
                <p className="text-xs text-white/60 mt-2">{plan.description}</p>
              </CardHeader>
              <CardContent className="p-6 flex-1 flex flex-col justify-between">
                <ul className="space-y-3 mb-8">
                  {plan.features.map(f => (
                    <li key={f} className="flex items-start gap-3 text-xs font-medium text-white/80">
                      <Check size={16} className="text-[#d4ff00] mt-0.5 flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Button 
                  onClick={() => handleSubscribe(plan)}
                  className={`w-full h-14 rounded-2xl font-black uppercase text-xs tracking-widest transition-all shadow-lg ${plan.popular ? 'bg-[#d4ff00] text-black hover:bg-[#c4eb00] shadow-[#d4ff00]/20' : 'bg-white/5 text-white hover:bg-white/10'}`}
                >
                  {plan.button}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="mt-12 p-6 bg-secondary/10 rounded-3xl border border-white/5 flex gap-4 items-center max-w-4xl mx-auto">
         <div className="w-12 h-12 rounded-2xl bg-[#d4ff00]/10 flex items-center justify-center text-[#d4ff00]">
            <Shield size={24} />
         </div>
         <div>
            <p className="text-xs font-black uppercase tracking-tight">100% SECURE PAYMENTS</p>
            <p className="text-[9px] text-muted-foreground uppercase font-bold mt-1">Processed instantly via local payment gateways. No hidden fees.</p>
         </div>
      </div>
    </div>
  );
};