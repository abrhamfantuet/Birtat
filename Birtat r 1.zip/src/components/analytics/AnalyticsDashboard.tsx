import React from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { TrendingUp, User, Weight, Activity, Camera, Box, Sparkles, Ruler } from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { UserProfile } from '../../lib/types';
import { Button } from '../ui/button';

const data = [
  { name: 'Week 1', volume: 12000, max: 80, weight: 81 },
  { name: 'Week 2', volume: 13500, max: 82.5, weight: 81.5 },
  { name: 'Week 3', volume: 15000, max: 85, weight: 82 },
  { name: 'Week 4', volume: 11000, max: 85, weight: 81.8 },
  { name: 'Week 5', volume: 16500, max: 87.5, weight: 82.5 },
];

export const AnalyticsDashboard: React.FC<{ userProfile: UserProfile | null }> = ({ userProfile }) => {
  const { t } = useLanguage();

  return (
    <div className="space-y-6 pb-24 px-4 pt-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header>
        <h1 className="text-3xl font-extrabold tracking-tight text-[#d4ff00]">{t('analytics')}</h1>
        <p className="text-muted-foreground text-sm font-medium">Quantifying your long-term progression.</p>
      </header>

      <section className="grid grid-cols-2 gap-4">
        <Card className="bg-secondary/20 border-white/5 overflow-hidden group">
          <CardContent className="p-0 h-48 relative">
            <img 
              src={userProfile?.selfieUrl || "https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/ai-coach---male-persona-319fe983-1775582317479.webp"} 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
              alt="Selfie" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
            <div className="absolute bottom-3 left-3 flex items-center gap-2">
              <Camera size={14} className="text-[#d4ff00]" />
              <span className="text-[10px] font-bold uppercase tracking-widest text-white">Latest Selfie</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-secondary/20 border-white/5 overflow-hidden border-[#d4ff00]/20">
          <CardContent className="p-0 h-48 relative group cursor-pointer">
            <img 
              src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/3d-model-wireframe-7b93fe3a-1775839395767.webp" 
              className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" 
              alt="3D Model" 
            />
            <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center opacity-100 group-hover:bg-[#d4ff00]/20 transition-all">
               <Box size={24} className="text-[#d4ff00] mb-2 animate-pulse" />
               <p className="text-[10px] font-black text-white tracking-widest">AI 3D SCAN</p>
            </div>
            <div className="absolute bottom-3 left-3 flex items-center gap-2">
              <Sparkles size={14} className="text-[#d4ff00]" />
              <span className="text-[10px] font-bold uppercase tracking-widest text-white">Live Topology</span>
            </div>
          </CardContent>
        </Card>
      </section>

      <div className="grid grid-cols-2 gap-4">
        <Card className="bg-secondary/20 border-white/5 border-l-2 border-l-[#d4ff00]">
          <CardContent className="p-4 flex flex-col items-center justify-center text-center">
            <div className="w-10 h-10 rounded-full bg-[#d4ff00]/10 flex items-center justify-center text-[#d4ff00] mb-2">
              <TrendingUp size={20} />
            </div>
            <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">Strength Gain</p>
            <p className="text-2xl font-black">+9.4%</p>
            <p className="text-[10px] text-green-500 font-bold mt-1 uppercase tracking-tighter">TOP 5% IN ETHIOPIA</p>
          </CardContent>
        </Card>
        <Card className="bg-secondary/20 border-white/5 border-l-2 border-l-blue-500">
          <CardContent className="p-4 flex flex-col items-center justify-center text-center">
            <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-500 mb-2">
              <Weight size={20} />
            </div>
            <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">Body Weight</p>
            <p className="text-2xl font-black">{userProfile?.weight || 82.5}kg</p>
            <p className="text-[10px] text-blue-500 font-bold mt-1 uppercase tracking-tighter">STABLE RECOVERY</p>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-secondary/10 border-white/5 overflow-hidden">
        <CardHeader className="p-4">
          <CardTitle className="text-xs font-black uppercase tracking-widest flex items-center gap-2">
            <Activity size={16} className="text-[#d4ff00]" /> Intensity Volume (kg)
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0 h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorVolume" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#d4ff00" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#d4ff00" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ffffff10" />
              <XAxis dataKey="name" fontSize={10} axisLine={false} tickLine={false} tick={{ fill: '#888' }} />
              <YAxis fontSize={10} axisLine={false} tickLine={false} tick={{ fill: '#888' }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#111', border: '1px solid #333', borderRadius: '12px', fontSize: '10px' }}
                itemStyle={{ color: '#d4ff00' }}
              />
              <Area type="monotone" dataKey="volume" stroke="#d4ff00" fillOpacity={1} fill="url(#colorVolume)" strokeWidth={3} />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="bg-secondary/20 border-white/5">
        <CardContent className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-black text-xs uppercase tracking-widest flex items-center gap-2">
               <Ruler size={16} className="text-[#d4ff00]" /> Measurements
            </h4>
            <Badge variant="outline" className="border-[#d4ff00]/30 text-[#d4ff00] text-[8px] font-black uppercase tracking-widest">{new Date().toLocaleDateString()}</Badge>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center p-3 rounded-2xl bg-black/40 border border-white/5">
              <p className="text-[8px] text-muted-foreground uppercase font-black tracking-tighter">Chest</p>
              <p className="text-sm font-black text-[#d4ff00]">{userProfile?.chest || 102} cm</p>
            </div>
            <div className="text-center p-3 rounded-2xl bg-black/40 border border-white/5">
              <p className="text-[8px] text-muted-foreground uppercase font-black tracking-tighter">Waist</p>
              <p className="text-sm font-black text-[#d4ff00]">{userProfile?.waist || 82} cm</p>
            </div>
            <div className="text-center p-3 rounded-2xl bg-black/40 border border-white/5">
              <p className="text-[8px] text-muted-foreground uppercase font-black tracking-tighter">Thigh</p>
              <p className="text-sm font-black text-[#d4ff00]">{userProfile?.thigh || 64} cm</p>
            </div>
          </div>
          <Button variant="outline" className="w-full mt-6 h-12 border-white/10 hover:bg-[#d4ff00]/10 hover:text-[#d4ff00] text-xs font-black uppercase tracking-widest">
            Update Body Stats
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};