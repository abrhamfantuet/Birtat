import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { 
  Lock, 
  Eye, 
  EyeOff, 
  Database, 
  Zap, 
  ShieldCheck, 
  Download, 
  Trash2, 
  User, 
  Mail, 
  Phone, 
  CreditCard, 
  Bell, 
  LogOut,
  ChevronRight,
  Shield,
  Clock,
  CheckCircle2
} from "lucide-react";
import { Button } from "../ui/button";
import { Switch } from "../ui/switch";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { toast } from "sonner";
import { UserProfile } from "../../lib/types";
import { PricingPlans } from "../pricing/PricingPlans";

export function SettingsPage({ userProfile }: { userProfile: UserProfile | null }) {
  const [privacySettings, setPrivacySettings] = useState({
    profileVisible: true,
    dataSync: true,
    aiProcessing: true,
    marketingEmails: false,
    pushNotifications: true
  });

  const [isEditingProfile, setIsEditingProfile] = useState(false);

  const handleExport = () => {
    toast.success("Data encryption protocol initiated. Download starting.");
  };

  const handleLogout = () => {
    localStorage.removeItem("birtat_profile");
    window.location.reload();
  };

  return (
    <div className="space-y-12 pb-32">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
        <div>
          <h2 className="text-xs font-black uppercase tracking-[0.4em] text-[#d4ff00] mb-2">Control & Privacy</h2>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-black italic uppercase tracking-tighter leading-none">
            Command <span className="text-[#d4ff00]">Center.</span>
          </h1>
        </div>
        <Button 
          variant="outline" 
          onClick={handleLogout}
          className="bg-white/5 border-white/10 text-white/60 hover:text-white rounded-2xl h-16 px-8 font-black uppercase italic text-sm"
        >
          <LogOut className="w-4 h-4 mr-3 text-red-500" /> TERMINATE SESSION
        </Button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-10 items-start">
        {/* Left Column - Profile & Settings */}
        <div className="xl:col-span-8 space-y-10">
          
          {/* Profile Section */}
          <section className="bg-[#0a0a0a] border border-white/5 rounded-[3rem] p-8 md:p-12 shadow-2xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none group-hover:scale-110 transition-transform duration-700">
               <User className="w-64 h-64 text-[#d4ff00]" />
            </div>
            
            <div className="flex items-center justify-between mb-10 relative z-10">
               <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-[#d4ff00]/10 flex items-center justify-center border border-[#d4ff00]/20 overflow-hidden shadow-2xl">
                     <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" alt="User" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black italic uppercase tracking-tight">Operator Intelligence</h3>
                    <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest mt-1">Personnel Record #AF-2024</p>
                  </div>
               </div>
               <Button 
                onClick={() => setIsEditingProfile(!isEditingProfile)}
                variant="ghost" 
                className="text-[#d4ff00] font-black uppercase italic text-xs h-10 px-6 rounded-xl border border-[#d4ff00]/20 hover:bg-[#d4ff00]/10"
               >
                 {isEditingProfile ? 'Lock File' : 'Edit Personnel'}
               </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10">
               <div className="space-y-3">
                  <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40">Registered Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#d4ff00]" />
                    <Input 
                      disabled={false}
                      defaultValue={userProfile?.email || "OPERATOR@ALIVEFIT.COM"}
                      className="pl-14 h-16 bg-white/5 border-white/10 rounded-2xl font-black italic uppercase text-sm focus:border-[#d4ff00]/50" 
                    />
                  </div>
               </div>
               <div className="space-y-3">
                  <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40">Secure Comms (Phone)</Label>
                  <div className="relative">
                    <Phone className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#d4ff00]" />
                    <Input 
                      disabled={false}
                      defaultValue={userProfile?.phoneNumber || "+1 (555) 000-0000"}
                      className="pl-14 h-16 bg-white/5 border-white/10 rounded-2xl font-black italic uppercase text-sm focus:border-[#d4ff00]/50" 
                    />
                  </div>
               </div>
               <div className="space-y-3">
                  <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40">Current Goal Protocol</Label>
                  <div className="h-16 flex items-center px-6 bg-white/5 border border-white/10 rounded-2xl">
                     <CheckCircle2 className="w-5 h-5 text-[#d4ff00] mr-4" />
                     <span className="font-black italic uppercase text-sm">{userProfile?.goal === 'fatLoss' ? 'Shred' : userProfile?.goal === 'hypertrophy' ? 'Mass Build' : 'Elite Force'}</span>
                  </div>
               </div>
               <div className="space-y-3">
                  <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40">Training Experience</Label>
                  <div className="h-16 flex items-center px-6 bg-white/5 border border-white/10 rounded-2xl">
                     <Clock className="w-5 h-5 text-[#d4ff00] mr-4" />
                     <span className="font-black italic uppercase text-sm">{userProfile?.fitnessLevel}</span>
                  </div>
               </div>
            </div>
          </section>

          {/* PRIVACY VAULT */}
          <section className="bg-[#0a0a0a] border border-[#d4ff00]/20 rounded-[3rem] p-8 md:p-12 shadow-[0_0_50px_rgba(212,255,0,0.05)]">
             <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 mb-12">
                <div className="flex items-center gap-5">
                   <div className="w-16 h-16 bg-[#d4ff00] text-black rounded-2xl flex items-center justify-center shadow-[0_0_30px_rgba(212,255,0,0.4)]">
                      <Shield size={32} />
                   </div>
                   <div>
                      <h3 className="text-3xl font-black italic uppercase tracking-tighter leading-none mb-2">Privacy <span className="text-[#d4ff00]">Protocol.</span></h3>
                      <p className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em]">Zero compromise on data sovereignty.</p>
                   </div>
                </div>
                <div className="flex flex-wrap items-center gap-4">
                   <Button variant="outline" className="border-white/10 text-white/60 hover:text-white rounded-xl h-14 px-8 font-black uppercase italic text-xs tracking-widest" onClick={handleExport}>
                      <Download className="w-4 h-4 mr-3" /> EXPORT PAYLOAD
                   </Button>
                   <Button variant="destructive" className="bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500 hover:text-white rounded-xl h-14 px-8 font-black uppercase italic text-xs tracking-widest">
                      <Trash2 className="w-4 h-4 mr-3" /> PURGE DATA
                   </Button>
                </div>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div className="bg-white/5 border border-white/10 p-8 rounded-[2.5rem] space-y-6 hover:border-[#d4ff00]/30 transition-all group">
                   <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                         <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center group-hover:text-[#d4ff00] transition-colors">
                            {privacySettings.profileVisible ? <Eye className="w-5 h-5" /> : <EyeOff className="w-5 h-5" />}
                         </div>
                         <span className="text-sm font-black uppercase italic">Tribal Presence</span>
                      </div>
                      <Switch 
                        checked={privacySettings.profileVisible} 
                        onCheckedChange={(val) => setPrivacySettings({...privacySettings, profileVisible: val})} 
                      />
                   </div>
                   <p className="text-[10px] text-white/40 leading-relaxed font-bold uppercase tracking-wide">
                      Visibility on global leaderboards and tribal discovery.
                   </p>
                </div>

                <div className="bg-white/5 border border-white/10 p-8 rounded-[2.5rem] space-y-6 hover:border-[#d4ff00]/30 transition-all group">
                   <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                         <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center group-hover:text-[#d4ff00] transition-colors">
                            <Database className="w-5 h-5" />
                         </div>
                         <span className="text-sm font-black uppercase italic">Sensor Link</span>
                      </div>
                      <Switch 
                        checked={privacySettings.dataSync} 
                        onCheckedChange={(val) => setPrivacySettings({...privacySettings, dataSync: val})} 
                      />
                   </div>
                   <p className="text-[10px] text-white/40 leading-relaxed font-bold uppercase tracking-wide">
                      Real-time synchronization with local fitness sensors.
                   </p>
                </div>

                <div className="bg-white/5 border border-white/10 p-8 rounded-[2.5rem] space-y-6 hover:border-[#d4ff00]/30 transition-all group">
                   <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                         <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center group-hover:text-[#d4ff00] transition-colors">
                            <Zap className="w-5 h-5" />
                         </div>
                         <span className="text-sm font-black uppercase italic">AI Intelligence</span>
                      </div>
                      <Switch 
                        checked={privacySettings.aiProcessing} 
                        onCheckedChange={(val) => setPrivacySettings({...privacySettings, aiProcessing: val})} 
                      />
                   </div>
                   <p className="text-[10px] text-white/40 leading-relaxed font-bold uppercase tracking-wide">
                      Process training logs for optimized transformation logic.
                   </p>
                </div>
             </div>
          </section>

          {/* Notifications */}
          <section className="bg-[#0a0a0a] border border-white/5 rounded-[3rem] p-8 md:p-12 shadow-2xl">
             <div className="flex items-center gap-5 mb-10">
                <div className="w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center text-[#d4ff00]">
                   <Bell size={24} />
                </div>
                <h3 className="text-2xl font-black italic uppercase tracking-tight">Deployment Alerts</h3>
             </div>
             
             <div className="space-y-6">
                <div className="flex items-center justify-between p-6 bg-white/5 rounded-2xl border border-white/5">
                   <div className="space-y-1">
                      <p className="text-sm font-black uppercase italic">Push Notifications</p>
                      <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest">Tactical reminders for daily missions</p>
                   </div>
                   <Switch 
                     checked={privacySettings.pushNotifications} 
                     onCheckedChange={(val) => setPrivacySettings({...privacySettings, pushNotifications: val})} 
                   />
                </div>
                <div className="flex items-center justify-between p-6 bg-white/5 rounded-2xl border border-white/5">
                   <div className="space-y-1">
                      <p className="text-sm font-black uppercase italic">Email Intelligence</p>
                      <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest">Weekly progress reports and tribal updates</p>
                   </div>
                   <Switch 
                     checked={privacySettings.marketingEmails} 
                     onCheckedChange={(val) => setPrivacySettings({...privacySettings, marketingEmails: val})} 
                   />
                </div>
             </div>
          </section>
        </div>

        {/* Right Column - Subscription */}
        <div className="xl:col-span-4 space-y-10">
           {/* Current Plan Card */}
           <div className="bg-[#d4ff00] p-10 rounded-[4rem] text-black shadow-[0_30px_60px_rgba(212,255,0,0.15)] relative overflow-hidden group">
              <div className="absolute -right-10 -top-10 opacity-5 group-hover:opacity-10 transition-opacity rotate-12">
                 <ShieldCheck className="w-64 h-64" />
              </div>
              <div className="relative z-10">
                 <div className="flex items-center gap-3 mb-8">
                    <span className="bg-black text-[#d4ff00] text-[10px] font-black px-4 py-1.5 rounded-full uppercase italic tracking-widest">Active Tier</span>
                 </div>
                 <h4 className="text-6xl font-black italic uppercase tracking-tighter leading-none mb-2">Pro <br /> Status.</h4>
                 <p className="text-sm font-black uppercase italic opacity-70 mb-10">Next Deployment: 12.04.2024</p>
                 
                 <div className="space-y-4 mb-10">
                    {["Full Logic Engine", "Video Archives", "Tribal Access"].map((feat, i) => (
                      <div key={i} className="flex items-center gap-3">
                         <CheckCircle2 size={16} />
                         <span className="text-xs font-black uppercase italic">{feat}</span>
                      </div>
                    ))}
                 </div>

                 <Button className="w-full h-16 bg-black text-white hover:bg-white hover:text-black rounded-2xl font-black uppercase italic text-xs tracking-widest transition-all">
                   Manage Billing <CreditCard className="ml-3 w-4 h-4" />
                 </Button>
              </div>
           </div>

           {/* Security Status */}
           <div className="bg-[#0a0a0a] border border-white/5 rounded-[3.5rem] p-10 shadow-2xl">
              <div className="flex items-center gap-4 mb-10">
                 <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-[#d4ff00]">
                    <Lock size={24} />
                 </div>
                 <h3 className="text-2xl font-black italic uppercase tracking-tight">Security Intel</h3>
              </div>
              <div className="space-y-8">
                 <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl">
                    <div className="flex items-center gap-4">
                       <Shield size={18} className="text-[#d4ff00]" />
                       <span className="text-[11px] font-black uppercase italic">Two-Factor</span>
                    </div>
                    <span className="text-[10px] font-black uppercase text-[#d4ff00] bg-[#d4ff00]/10 px-3 py-1 rounded-md">Enabled</span>
                 </div>
                 <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl">
                    <div className="flex items-center gap-4">
                       <Clock size={18} className="text-blue-500" />
                       <span className="text-[11px] font-black uppercase italic">Last Access</span>
                    </div>
                    <span className="text-[10px] font-black uppercase text-white/30 italic">2 Minutes Ago</span>
                 </div>
              </div>
              <button className="w-full mt-10 py-5 rounded-2xl border-2 border-white/10 text-[10px] font-black uppercase tracking-widest hover:bg-[#d4ff00] hover:text-black hover:border-[#d4ff00] transition-all flex items-center justify-center gap-3 group">
                Reset Secure Cipher <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
           </div>
        </div>
      </div>

      {/* Embedded Pricing */}
      <div className="pt-20 border-t border-white/5">
        <PricingPlans onSelect={(plan) => toast.info(`Initializing migration to ${plan} tier.`)} />
      </div>
    </div>
  );
}