import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, User, Settings, Shield, LogOut, X, Info, CreditCard, Mail, Phone, ChevronRight, Save, Trash2, Download, Smartphone, Languages } from 'lucide-react';
import { useLanguage, LanguageSwitcher } from '../LanguageSwitcher';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Switch } from '../ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { UserProfile } from '../../lib/types';
import { toast } from 'sonner';
import { usePWA } from '../../hooks/usePWA';

interface SettingsSheetProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile | null;
  onLogout: () => void;
  initialTab?: string;
}

export const SettingsSheet: React.FC<SettingsSheetProps> = ({ isOpen, onClose, userProfile, onLogout, initialTab = 'profile' }) => {
  const { t } = useLanguage();
  const { isInstallable, installApp } = usePWA();

  const handleSave = () => {
    toast.success("Settings saved successfully!");
    onClose();
  };

  const handleClearData = () => {
    if (confirm("Are you sure you want to clear all local data? This cannot be undone.")) {
      localStorage.clear();
      window.location.reload();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100]"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 h-full w-full max-w-md bg-[#050505] border-l border-white/5 z-[101] shadow-2xl flex flex-col"
          >
            <div className="p-6 border-b border-white/5 flex items-center justify-between bg-black/20">
              <div>
                <h2 className="text-xl font-black uppercase italic tracking-tighter text-[#d4ff00]">{t('settings')}</h2>
                <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">{t('settingsSubtitle')}</p>
              </div>
              <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full hover:bg-white/5">
                <X size={20} />
              </Button>
            </div>

            <div className="flex-1 overflow-y-auto p-6">
              <Tabs defaultValue={initialTab} className="w-full">
                <TabsList className="w-full bg-secondary/20 p-1 mb-8">
                  <TabsTrigger value="profile" className="flex-1 gap-2 text-[10px] font-black uppercase">
                    <User size={14} /> {t('profile')}
                  </TabsTrigger>
                  <TabsTrigger value="privacy" className="flex-1 gap-2 text-[10px] font-black uppercase">
                    <Shield size={14} /> {t('privacy')}
                  </TabsTrigger>
                  <TabsTrigger value="account" className="flex-1 gap-2 text-[10px] font-black uppercase">
                    <Settings size={14} /> {t('appName')}
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="profile" className="space-y-6">
                  <div className="flex flex-col items-center gap-4 mb-8">
                    <div className="relative group">
                      <div className="w-24 h-24 rounded-3xl border-2 border-[#d4ff00]/20 overflow-hidden bg-secondary/40">
                        <img src={userProfile?.selfieUrl || "https://i.pravatar.cc/150?u=user"} className="w-full h-full object-cover" alt="Profile" />
                      </div>
                      <button className="absolute -bottom-2 -right-2 p-2 bg-[#d4ff00] text-black rounded-xl shadow-lg hover:scale-110 transition-transform">
                        <Save size={14} />
                      </button>
                    </div>
                    <div className="text-center">
                      <h3 className="text-lg font-black uppercase italic">{userProfile?.email?.split('@')[0]}</h3>
                      <p className="text-[10px] text-[#d4ff00] font-black tracking-widest uppercase">{userProfile?.isPro ? 'PRO ATHLETE' : 'FREE ATHLETE'}</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-[10px] font-black uppercase text-muted-foreground pl-1">Email Address</Label>
                      <div className="relative">
                        <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20" size={16} />
                        <Input defaultValue={userProfile?.email} className="bg-white/5 border-white/5 h-12 pl-12 rounded-xl font-bold" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] font-black uppercase text-muted-foreground pl-1">Phone Number</Label>
                      <div className="relative">
                        <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20" size={16} />
                        <Input defaultValue={userProfile?.phoneNumber} className="bg-white/5 border-white/5 h-12 pl-12 rounded-xl font-bold" />
                      </div>
                    </div>
                  </div>

                  <Button onClick={handleSave} className="w-full h-14 bg-[#d4ff00] text-black font-black uppercase rounded-2xl shadow-lg shadow-[#d4ff00]/10 mt-4">
                    SAVE CHANGES
                  </Button>
                </TabsContent>

                <TabsContent value="privacy" className="space-y-6">
                  <div className="bg-[#d4ff00]/5 border border-[#d4ff00]/10 p-4 rounded-2xl flex gap-4">
                    <Shield size={24} className="text-[#d4ff00] flex-shrink-0" />
                    <div>
                      <h4 className="text-xs font-black uppercase text-[#d4ff00]">Privacy Shield Active</h4>
                      <p className="text-[10px] text-white/60 leading-relaxed mt-1">
                        Your biometric data and progress photos are encrypted locally on this device. We never sell or share your data.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                      <div>
                        <p className="text-xs font-bold">Biometric Data Sync</p>
                        <p className="text-[9px] text-muted-foreground">Keep data only on this device</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                      <div>
                        <p className="text-xs font-bold">Incognito Mode</p>
                        <p className="text-[9px] text-muted-foreground">Hide profile from community</p>
                      </div>
                      <Switch />
                    </div>
                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                      <div>
                        <p className="text-xs font-bold">AI Analytics Tracking</p>
                        <p className="text-[9px] text-muted-foreground">Allow AI to improve your plans</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>

                  <div className="pt-6 border-t border-white/5 space-y-3">
                     <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest pl-1">Data Management</p>
                     <Button variant="outline" className="w-full justify-start gap-3 h-12 border-white/5 hover:bg-white/5 font-bold text-xs" onClick={() => toast.success("Exporting data as JSON...")}>
                        <Download size={16} /> {t('dataExport')}
                     </Button>
                     <Button variant="outline" className="w-full justify-start gap-3 h-12 border-white/5 hover:bg-red-500/10 hover:text-red-500 hover:border-red-500/20 font-bold text-xs" onClick={handleClearData}>
                        <Trash2 size={16} /> {t('clearData')}
                     </Button>
                  </div>
                </TabsContent>

                <TabsContent value="account" className="space-y-6">
                  {isInstallable && (
                    <div className="bg-[#d4ff00] p-4 rounded-2xl flex items-center justify-between mb-4 shadow-lg shadow-[#d4ff00]/20">
                      <div className="flex gap-3 items-center">
                        <div className="bg-black/10 p-2 rounded-xl text-black">
                          <Smartphone size={20} />
                        </div>
                        <div>
                          <p className="text-xs font-black text-black leading-tight uppercase">Install BIRTAT</p>
                          <p className="text-[9px] text-black/60 font-bold uppercase tracking-tighter">Add to your home screen</p>
                        </div>
                      </div>
                      <Button size="sm" onClick={installApp} className="bg-black text-white hover:bg-black/80 font-black text-[10px] uppercase rounded-xl h-8">
                        INSTALL
                      </Button>
                    </div>
                  )}

                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                      <div className="flex items-center gap-3">
                        <div className="bg-[#d4ff00]/10 p-2 rounded-xl text-[#d4ff00]">
                          <Languages size={20} />
                        </div>
                        <div>
                          <p className="text-xs font-bold">App Language</p>
                          <p className="text-[9px] text-muted-foreground">Change interface language</p>
                        </div>
                      </div>
                      <LanguageSwitcher />
                    </div>

                    <Button variant="outline" className="w-full justify-between h-14 border-white/5 hover:bg-white/5 font-bold rounded-2xl px-6">
                      <span className="flex items-center gap-3"><CreditCard size={18} className="text-[#d4ff00]" /> Subscription</span>
                      <Badge className="bg-[#d4ff00] text-black">PRO</Badge>
                    </Button>
                    <Button variant="outline" className="w-full justify-between h-14 border-white/5 hover:bg-white/5 font-bold rounded-2xl px-6">
                      <span className="flex items-center gap-3"><Info size={18} className="text-[#d4ff00]" /> Terms of Service</span>
                      <ChevronRight size={18} className="text-white/20" />
                    </Button>
                    <Button variant="outline" className="w-full justify-between h-14 border-white/5 hover:bg-white/5 font-bold rounded-2xl px-6">
                      <span className="flex items-center gap-3"><Shield size={18} className="text-[#d4ff00]" /> Security Policy</span>
                      <ChevronRight size={18} className="text-white/20" />
                    </Button>
                  </div>

                  <div className="pt-12">
                     <Button 
                       onClick={onLogout}
                       variant="destructive" 
                       className="w-full h-14 bg-red-500/10 hover:bg-red-500/20 text-red-500 border border-red-500/20 font-black uppercase rounded-2xl shadow-lg shadow-red-500/5"
                     >
                       <LogOut size={18} className="mr-2" /> {t('logout')}
                     </Button>
                  </div>

                  <div className="text-center pt-8">
                     <p className="text-[8px] font-black text-white/20 uppercase tracking-[0.2em]">Birtat v1.0.4 Premium</p>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};