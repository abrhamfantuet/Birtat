import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, Navigation, Star, Map as MapIcon, List, Search, Loader2, Info } from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { toast } from 'sonner';

interface Gym {
  id: number;
  name: string;
  rating: number;
  distance: string;
  image: string;
  lat: number;
  lng: number;
  address: string;
}

const MOCK_GYMS: Gym[] = [
  { 
    id: 1, 
    name: 'Addis Fitness Elite', 
    rating: 4.9, 
    distance: '0.8 km', 
    image: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/addis-elite-fitness-0a033c63-1776583931708.webp',
    lat: 9.0227,
    lng: 38.7460,
    address: 'Bole, Near Friendship Mall'
  },
  { 
    id: 2, 
    name: 'Birtat Partner Gym', 
    rating: 5.0, 
    distance: '1.2 km', 
    image: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/birtat-partner-gym-c25fe872-1776583932260.webp',
    lat: 9.0300,
    lng: 38.7500,
    address: 'Haya Hulet, Century Mall'
  },
  { 
    id: 3, 
    name: 'Skyline Fitness Center', 
    rating: 4.7, 
    distance: '2.5 km', 
    image: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/skyline-gym-a229a075-1776583932973.webp',
    lat: 9.0100,
    lng: 38.7600,
    address: 'Sarbet, Near African Union'
  }
];

export const NearbyGyms: React.FC = () => {
  const { t } = useLanguage();
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [selectedGym, setSelectedGym] = useState<Gym | null>(null);

  const requestLocation = () => {
    setIsLoading(true);
    if (!navigator.geolocation) {
      toast.error("Geolocation is not supported by your browser");
      setIsLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude
        });
        setIsLoading(false);
        toast.success("Location synced successfully");
      },
      (error) => {
        console.error(error);
        toast.error("Unable to retrieve your location. Please check your permissions.");
        setIsLoading(false);
      }
    );
  };

  return (
    <section className="px-4 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-black uppercase tracking-widest text-white flex items-center gap-2">
          <MapPin size={14} className="text-[#d4ff00]" /> {t('nearbyGyms') || 'NEARBY GYMS'}
        </h3>
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setViewMode(viewMode === 'list' ? 'map' : 'list')}
            className="text-[10px] font-black uppercase h-7 px-2 border border-white/10 hover:bg-[#d4ff00]/10 hover:text-[#d4ff00]"
          >
            {viewMode === 'list' ? <MapIcon size={12} className="mr-1" /> : <List size={12} className="mr-1" />}
            {viewMode === 'list' ? 'Map View' : 'List View'}
          </Button>
          {!location && (
            <Button 
              onClick={requestLocation} 
              disabled={false}
              className="bg-[#d4ff00] text-black hover:bg-[#d4ff00]/90 text-[10px] font-black h-7 px-3 rounded-full flex items-center gap-1 shadow-[0_0_15px_rgba(212,255,0,0.3)]"
            >
              {isLoading ? <Loader2 size={12} className="animate-spin" /> : <Navigation size={12} />}
              LOCATE
            </Button>
          )}
        </div>
      </div>

      <AnimatePresence mode="wait">
        {viewMode === 'map' ? (
          <motion.div
            key="map-view"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="relative h-[300px] w-full rounded-2xl overflow-hidden border border-white/10 bg-black/40 backdrop-blur-sm"
          >
            {location ? (
              <div className="relative w-full h-full">
                <div className="absolute inset-0 bg-[#111] flex flex-col items-center justify-center text-center p-6 space-y-4">
                  <div className="w-16 h-16 bg-[#d4ff00]/10 rounded-full flex items-center justify-center border border-[#d4ff00]/30 animate-pulse">
                    <MapIcon className="text-[#d4ff00]" size={32} />
                  </div>
                  <div className="space-y-2 max-w-xs">
                    <h4 className="text-sm font-bold uppercase tracking-tight">Interactive Google Map</h4>
                    <p className="text-[10px] text-muted-foreground font-medium">
                      Google Maps Platform integration ready. Connect your API key to visualize nearby gyms in real-time.
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full space-y-4 bg-white/5">
                <Navigation size={40} className="text-muted-foreground/30" />
                <p className="text-xs text-muted-foreground font-bold uppercase tracking-widest">Enable location to view map</p>
                <Button onClick={requestLocation} disabled={false} variant="outline" size="sm" className="rounded-full text-[10px] font-black">GRANT PERMISSION</Button>
              </div>
            )}
          </motion.div>
        ) : (
          <motion.div 
            key="list-view"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex gap-4 overflow-x-auto no-scrollbar pb-2"
          >
            {MOCK_GYMS.map((gym, idx) => (
              <motion.div 
                key={gym.id} 
                initial={{ opacity: 0, scale: 0.9 }} 
                animate={{ opacity: 1, scale: 1 }} 
                transition={{ delay: idx * 0.1 }}
                className="flex-shrink-0 w-64"
                onClick={() => setSelectedGym(gym)}
              >
                 <Card className={`bg-secondary/20 border-white/5 overflow-hidden group cursor-pointer transition-all ${selectedGym?.id === gym.id ? 'border-[#d4ff00]/50 bg-[#d4ff00]/5' : ''}`}>
                    <div className="h-32 relative">
                      <img src={gym.image} className="w-full h-full object-cover transition-transform group-hover:scale-105" alt={gym.name} />
                      <div className="absolute top-2 right-2">
                        <Badge className="bg-black/60 backdrop-blur-md border-none flex items-center gap-1 text-[10px] font-black">
                          <Star size={10} className="text-[#d4ff00] fill-[#d4ff00]" /> {gym.rating}
                        </Badge>
                      </div>
                    </div>
                    <CardContent className="p-3">
                      <div className="flex justify-between items-start gap-2">
                        <div>
                          <h4 className="font-black text-[11px] uppercase tracking-tight group-hover:text-[#d4ff00] transition-colors">{gym.name}</h4>
                          <p className="text-[9px] text-muted-foreground font-medium mt-0.5">{gym.address}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-[10px] font-black text-[#d4ff00] italic leading-none">{gym.distance}</p>
                          <p className="text-[8px] text-muted-foreground uppercase font-bold">Away</p>
                        </div>
                      </div>
                    </CardContent>
                 </Card>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {!location && (
        <Card className="bg-white/5 border-dashed border-white/10 p-4 text-center">
          <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-relaxed">
            Allow location access to find gyms near your current position.
          </p>
        </Card>
      )}
    </section>
  );
};