import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Zap, Target, Timer, Calendar, Sparkles, Wand2, BarChart3, Star, ArrowLeft, Trophy } from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Calendar as CalendarUI } from '../ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { UserProfile, WorkoutPlan } from '../../lib/types';
import { toast } from 'sonner';
import { TransformationPrograms } from '../programs/TransformationPrograms';
import { AnalyticsDashboard } from '../analytics/AnalyticsDashboard';
import { WorkoutDetail } from './WorkoutDetail';
import { NearbyGyms } from './NearbyGyms';

export const WorkoutDashboard: React.FC<{ onStart: () => void, userProfile: UserProfile | null }> = ({ onStart, userProfile }) => {
  const { t } = useLanguage();
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [isGeneratingPlan, setIsGeneratingPlan] = useState(false);
  const [view, setView] = useState<'daily' | 'programs' | 'analytics'>('daily');
  const [selectedWorkout, setSelectedWorkout] = useState<WorkoutPlan | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  const workouts: WorkoutPlan[] = [
    { 
      id: 1, 
      name: 'Push A - Hypertrophy', 
      duration: '65 min', 
      intensity: 'High',
      exercises: [
        { name: 'Bench Press (Barbell)', sets: 4, reps: '8-10 Reps', image: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/landing-hero-b2cde00d-1775764063529.webp', instruction: 'Keep shoulder blades retracted and drive through feet.' },
      ]
    },
  ];

  const handleGeneratePlan = () => {
    setIsGeneratingPlan(true);
    setTimeout(() => {
      setIsGeneratingPlan(false);
      toast.success("Personalized Plan Generated Based on your Profile!");
      setSelectedWorkout(workouts[0]);
      setIsDetailOpen(true);
    }, 2000);
  };

  const renderMainContent = () => {
    if (view === 'programs') return <TransformationPrograms />;
    if (view === 'analytics') return <AnalyticsDashboard userProfile={userProfile} />;

    return (
      <div className="space-y-6">
        <section className="px-4">
          <motion.div 
            whileTap={{ scale: 0.98 }}
            onClick={onStart}
            className="relative h-48 rounded-3xl overflow-hidden cursor-pointer shadow-2xl group border border-white/5"
          >
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
              <div>
                <p className="text-[#d4ff00] text-xs font-bold uppercase tracking-widest mb-1">{t('startWorkout')}</p>
                <h2 className="text-2xl font-black text-white uppercase tracking-tighter italic">
                  {userProfile?.goal === 'hypertrophy' ? 'Muscle Engine' : 'Peak Hybrid'}
                </h2>
              </div>
              <div className="bg-[#d4ff00] p-3 rounded-full shadow-[0_0_20px_rgba(212,255,0,0.5)]">
                <Play className="text-black fill-black" size={24} />
              </div>
            </div>
          </motion.div>
        </section>

        <section className="px-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-widest text-white">{t('generatePlan')}</h3>
            <Button onClick={handleGeneratePlan} disabled={false} variant="ghost" className="text-[#d4ff00] text-xs font-bold flex items-center gap-1 hover:bg-[#d4ff00]/10 h-8">
              {isGeneratingPlan ? <Zap className="animate-spin" size={14} /> : <Wand2 size={14} />}
              SYNC AI
            </Button>
          </div>

          <div className="space-y-3">
            {workouts.map((w, idx) => (
              <motion.div 
                key={w.id} 
                initial={{ opacity: 0, x: -20 }} 
                animate={{ opacity: 1, x: 0 }} 
                transition={{ delay: idx * 0.1 }}
                onClick={() => { setSelectedWorkout(w); setIsDetailOpen(true); }}
              >
                <Card className="bg-secondary/20 border-white/5 hover:border-[#d4ff00]/30 transition-all cursor-pointer overflow-hidden group">
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-muted-foreground group-hover:bg-[#d4ff00] group-hover:text-black transition-colors">
                      <Zap size={20} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-bold text-sm">{w.name}</h4>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="text-[10px] text-muted-foreground font-bold flex items-center gap-1"><Timer size={10} /> {w.duration}</span>
                      </div>
                    </div>
                    <Badge variant="secondary" className="text-[9px] bg-secondary/50 font-black tracking-tighter">{w.intensity}</Badge>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        <NearbyGyms />
      </div>
    );
  };

  return (
    <div className="space-y-6 pb-24 px-4 pt-4">
      <header>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold uppercase tracking-tight">{t('workout')}</h2>
          <div className="flex items-center gap-2">
            <Button onClick={() => setView('analytics')} variant="outline" size="icon" className="rounded-full border-white/5 bg-white/5 hover:bg-[#d4ff00]/10 hover:text-[#d4ff00] transition-colors">
              <BarChart3 size={18} />
            </Button>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="icon" className="rounded-full border-white/5 bg-white/5 hover:bg-[#d4ff00]/10 hover:text-[#d4ff00] transition-colors">
                  <Calendar size={18} />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 bg-[#111] border-white/10" align="end">
                <CalendarUI mode="single" selected={date} onSelect={setDate} initialFocus className="bg-[#111] text-white" />
              </PopoverContent>
            </Popover>
          </div>
        </div>
        
        <div className="flex gap-4">
           <button onClick={() => setView('daily')} className={`flex-1 py-2 text-[10px] font-black uppercase tracking-widest border-b-2 transition-colors ${view === 'daily' ? 'border-[#d4ff00] text-[#d4ff00]' : 'border-transparent text-muted-foreground'}`}>
              {t('daily')}
           </button>
           <button onClick={() => setView('programs')} className={`flex-1 py-2 text-[10px] font-black uppercase tracking-widest border-b-2 transition-colors ${view === 'programs' ? 'border-[#d4ff00] text-[#d4ff00]' : 'border-transparent text-muted-foreground'}`}>
              {t('programs')}
           </button>
        </div>
      </header>

      <AnimatePresence mode="wait">
        <motion.div
          key={view}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.3, ease: "easeInOut" }}
        >
          {renderMainContent()}
        </motion.div>
      </AnimatePresence>

      <WorkoutDetail 
        workout={selectedWorkout} 
        isOpen={isDetailOpen} 
        onClose={() => setIsDetailOpen(false)} 
        onStart={onStart}
      />
    </div>
  );
};