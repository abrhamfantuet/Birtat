import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, ChevronLeft, Plus, TrendingUp, Info } from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { toast } from 'sonner';
import { UserProfile } from '../../lib/types';

export const WorkoutLogger: React.FC<{ onFinish: () => void, userProfile: UserProfile | null }> = ({ onFinish, userProfile }) => {
  const { t } = useLanguage();
  const [sets, setSets] = useState([
    { id: '1', weight: 80, reps: 8, rir: 2, completed: false },
    { id: '2', weight: 80, reps: 8, rir: 1, completed: false },
    { id: '3', weight: 80, reps: 7, rir: 0, completed: false },
  ]);

  const toggleSet = (id: string) => {
    setSets(sets.map(s => s.id === id ? { ...s, completed: !s.completed } : s));
  };

  const addSet = () => {
    const lastSet = sets[sets.length - 1];
    setSets([...sets, { ...lastSet, id: Date.now().toString(), completed: false }]);
  };

  const handleFinish = () => {
    toast.success('Session Logged! You are unstoppable.');
    onFinish();
  };

  return (
    <div className="min-h-screen bg-[#050505] pb-32">
      <header className="sticky top-0 z-40 bg-[#050505]/80 backdrop-blur-lg border-b border-white/5 px-4 h-16 flex items-center justify-between">
        <button onClick={onFinish} className="p-2 -ml-2 text-white/40 hover:text-white">
          <ChevronLeft size={24} />
        </button>
        <h2 className="font-black uppercase italic tracking-tighter">Bench Press (Barbell)</h2>
        <button className="text-[#d4ff00] font-black uppercase italic text-sm tracking-tighter" onClick={handleFinish}>{t('finish')}</button>
      </header>

      <div className="p-4 space-y-6">
        <div className="flex gap-4 items-center bg-white/5 p-4 rounded-3xl border border-white/5">
          <div className="w-20 h-20 rounded-2xl overflow-hidden bg-secondary">
            <img src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/landing-hero-b2cde00d-1775764063529.webp" className="w-full h-full object-cover" alt="exercise" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 text-[#d4ff00]">
              <TrendingUp size={14} />
              <span className="text-[10px] font-black uppercase tracking-widest">Logic Analysis</span>
            </div>
            <p className="text-sm font-black uppercase italic mt-1">Target: {userProfile?.fitnessLevel === 'beginner' ? 'Strict Form' : '95% RM (RIR 1)'}</p>
            <p className="text-[10px] text-white/40 font-bold uppercase tracking-widest mt-1">Last Session: 82.5kg x 6</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-5 gap-2 px-2 text-[8px] font-black text-white/20 uppercase tracking-[0.2em] text-center">
            <div>Set</div>
            <div>Last</div>
            <div>kg</div>
            <div>Reps</div>
            <div>Check</div>
          </div>

          {sets.map((set, idx) => (
            <motion.div 
              key={set.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.05 }}
              className={`grid grid-cols-5 gap-2 items-center p-3 rounded-2xl border transition-all ${set.completed ? 'bg-[#d4ff00]/10 border-[#d4ff00]/30' : 'bg-white/5 border-white/5'}`}
            >
              <div className="text-center font-black italic">{idx + 1}</div>
              <div className="text-center text-[10px] font-bold text-white/30 uppercase tracking-tighter">80x8</div>
              <Input 
                type="number" 
                defaultValue={set.weight} 
                className="h-10 text-center bg-black/40 border-none text-sm font-black text-white px-1 rounded-xl" 
              />
              <Input 
                type="number" 
                defaultValue={set.reps} 
                className="h-10 text-center bg-black/40 border-none text-sm font-black text-white px-1 rounded-xl" 
              />
              <button 
                onClick={() => toggleSet(set.id)}
                className={`flex items-center justify-center h-10 rounded-xl transition-all ${set.completed ? 'bg-[#d4ff00] text-black shadow-lg shadow-[#d4ff00]/20' : 'bg-white/5 text-white/20'}`}
              >
                <CheckCircle2 size={18} fill={set.completed ? 'currentColor' : 'none'} />
              </button>
            </motion.div>
          ))}

          <Button 
            variant="ghost" 
            className="w-full border-2 border-dashed border-white/5 text-white/20 hover:bg-white/5 h-14 rounded-2xl font-black uppercase italic tracking-widest"
            onClick={addSet}
          >
            <Plus size={18} className="mr-2" /> Add Set
          </Button>
        </div>

        <div className="bg-[#0a0a0a] border-l-4 border-[#d4ff00] p-6 rounded-3xl mt-8">
          <h3 className="text-xs font-black uppercase tracking-[0.2em] mb-3 flex items-center gap-2 text-[#d4ff00]">
            <Info size={14} /> Coach AI Deep Dive
          </h3>
          <p className="text-sm text-white/60 leading-relaxed font-medium italic">
            "Your explosive power is peak today. Based on your {userProfile?.goal} goal, we are pushing for maximal recruitment in this final set. Do not leave anything in the tank."
          </p>
        </div>
      </div>
    </div>
  );
};