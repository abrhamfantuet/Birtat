import React from 'react';
import { motion } from 'framer-motion';
import { Play, Clock, Target, ChevronRight, Info, Zap } from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetFooter } from '../ui/sheet';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { WorkoutPlan } from '../../lib/types';
import { useLanguage } from '../LanguageSwitcher';

interface WorkoutDetailProps {
  workout: WorkoutPlan | null;
  isOpen: boolean;
  onClose: () => void;
  onStart: () => void;
}

export const WorkoutDetail: React.FC<WorkoutDetailProps> = ({ workout, isOpen, onClose, onStart }) => {
  const { t } = useLanguage();

  if (!workout) return null;

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="bottom" className="h-[92vh] bg-[#050505] border-white/10 rounded-t-[32px] p-0 flex flex-col overflow-hidden">
        <div className="absolute top-3 left-1/2 -translate-x-1/2 w-12 h-1.5 bg-white/10 rounded-full z-50" />
        
        <div className="flex-1 overflow-y-auto no-scrollbar">
          <div className="relative h-64 w-full">
            <img 
              src={workout.exercises[0]?.image || "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80"} 
              className="w-full h-full object-cover" 
              alt={workout.name} 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-black/40 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6">
              <Badge className="mb-3 bg-[#d4ff00] text-black font-black uppercase tracking-widest border-none">
                {workout.intensity} {t('intensity') || 'INTENSITY'}
              </Badge>
              <h2 className="text-3xl font-black text-white uppercase tracking-tighter italic leading-none mb-2">
                {workout.name}
              </h2>
              <div className="flex items-center gap-4 text-white/60 text-xs font-bold uppercase tracking-widest">
                <span className="flex items-center gap-1.5"><Clock size={14} className="text-[#d4ff00]" /> {workout.duration}</span>
                <span className="flex items-center gap-1.5"><Target size={14} className="text-[#d4ff00]" /> {workout.exercises.length} Exercises</span>
              </div>
            </div>
          </div>

          <div className="p-6 space-y-8 pb-32">
            <div className="space-y-4">
              <h3 className="text-xs font-black uppercase tracking-[0.2em] text-[#d4ff00] flex items-center gap-2">
                <Zap size={14} fill="currentColor" /> Workout Protocol
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white/5 border border-white/5 rounded-2xl p-4">
                  <p className="text-[10px] text-white/40 font-black uppercase tracking-widest mb-1">Rest periods</p>
                  <p className="text-sm font-bold">60-90 Seconds</p>
                </div>
                <div className="bg-white/5 border border-white/5 rounded-2xl p-4">
                  <p className="text-[10px] text-white/40 font-black uppercase tracking-widest mb-1">Focus goal</p>
                  <p className="text-sm font-bold italic uppercase">Progressive Overload</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black uppercase tracking-[0.2em] text-white/60">Exercise List</h3>
                <span className="text-[10px] font-black text-[#d4ff00] uppercase tracking-widest">{workout.exercises.length} Movements</span>
              </div>
              
              <div className="space-y-3">
                {workout.exercises.map((exercise, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 + idx * 0.05 }}
                    className="group flex items-center gap-4 p-3 bg-white/5 border border-white/5 rounded-2xl hover:bg-white/10 transition-colors cursor-pointer"
                  >
                    <div className="w-16 h-16 rounded-xl overflow-hidden bg-black flex-shrink-0">
                      <img src={exercise.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt={exercise.name} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-sm uppercase italic truncate">{exercise.name}</h4>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] font-black text-[#d4ff00] uppercase tracking-tighter">{exercise.sets} Sets</span>
                        <Separator orientation="vertical" className="h-2 bg-white/20" />
                        <span className="text-[10px] font-black text-white/40 uppercase tracking-tighter">{exercise.reps}</span>
                      </div>
                    </div>
                    <div className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-white/20 group-hover:text-[#d4ff00] group-hover:border-[#d4ff00]/50 transition-colors">
                      <ChevronRight size={16} />
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            <div className="bg-[#d4ff00]/10 border-l-4 border-[#d4ff00] p-5 rounded-2xl">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-[#d4ff00] mb-2 flex items-center gap-2">
                <Info size={14} /> AI Coaching Tip
              </h4>
              <p className="text-xs text-white/70 italic leading-relaxed">
                "Today's session focuses on explosive eccentric movements. Ensure you control the weight on the way down for at least 3 seconds to maximize muscle fiber recruitment."
              </p>
            </div>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-[#050505] via-[#050505] to-transparent pt-12">
          <Button 
            onClick={() => {
              onStart();
              onClose();
            }} 
            className="w-full h-16 bg-[#d4ff00] hover:bg-[#c4eb00] text-black font-black uppercase italic tracking-[0.1em] text-lg rounded-2xl shadow-[0_10px_30px_rgba(212,255,0,0.3)] transition-all active:scale-95 group"
          >
            {t('startWorkout') || 'START SESSION'}
            <Play className="ml-2 group-hover:translate-x-1 transition-transform fill-black" size={20} />
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
};