import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Send, Bot, SwitchCamera, Brain, Target, ShieldCheck, Zap } from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { UserProfile } from '../../lib/types';

export const AICoach: React.FC<{ userProfile: UserProfile | null }> = ({ userProfile }) => {
  const { t } = useLanguage();
  const [persona, setPersona] = useState<'male' | 'female'>('male');
  const [messages, setMessages] = useState([
    { role: 'ai', text: "Protocol Initialized. I am your AliveFit Elite Coach. I've analyzed your biological stats and goal-oriented data. How shall we optimize your transformation today?" },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = () => {
    if (!input.trim()) return;

    const userMsg = { role: 'user', text: input };
    setMessages([...messages, userMsg]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      setIsTyping(false);
      const aiResponse = { 
        role: 'ai', 
        text: getMockResponse(input, persona) 
      };
      setMessages(prev => [...prev, aiResponse]);
    }, 1500);
  };

  const getMockResponse = (query: string, p: 'male' | 'female') => {
    const q = query.toLowerCase();
    if (q.includes('protein')) return `Based on your ${userProfile?.weight}kg frame and ${userProfile?.goal} objective, target 2.2g of protein per kg. That is ${Math.round((userProfile?.weight || 75) * 2.2)}g daily. No excuses.`;
    if (q.includes('bench') || q.includes('chest')) return "Chest mechanics verified. To overcome your plateau, implement 2-second isometric holds at the bottom. Increase intensity by 5% next session.";
    if (q.includes('discipline')) return `Discipline is the bridge between goals and accomplishment. Your ${userProfile?.streak} day streak is a baseline. We do not negotiate with laziness.`;
    return `Analysis complete. For an ${userProfile?.fitnessLevel} level athlete, consistency is the primary variable. Stick to the protocol and the results will follow.`;
  };

  const coachAvatars = {
    male: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/ai-coach---male-persona-319fe983-1775582317479.webp',
    female: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/ai-coach---female-persona-62ba4586-1775582317945.webp'
  };

  return (
    <div className="flex flex-col h-screen pb-24">
      <header className="px-6 pt-8 pb-4 bg-[#050505]/80 backdrop-blur-md sticky top-0 z-10 border-b border-white/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-14 h-14 rounded-2xl overflow-hidden border-2 border-[#d4ff00] p-0.5">
                <img src={coachAvatars[persona]} className="w-full h-full object-cover rounded-xl" alt="AI Coach" />
              </div>
              <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-[#d4ff00] border-2 border-[#050505] rounded-full flex items-center justify-center">
                 <Zap size={8} className="text-black fill-current" />
              </div>
            </div>
            <div>
              <h1 className="text-xl font-black italic uppercase tracking-tighter flex items-center gap-2">
                Coach {persona === 'male' ? 'KAI' : 'NOVA'}
              </h1>
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                <p className="text-[10px] text-[#d4ff00] font-black uppercase tracking-[0.2em]">Logic Active</p>
              </div>
            </div>
          </div>
          <button 
            onClick={() => setPersona(p => p === 'male' ? 'female' : 'male')}
            className="p-3 rounded-2xl bg-white/5 text-white/40 hover:text-[#d4ff00] border border-white/5 transition-all"
          >
            <SwitchCamera size={20} />
          </button>
        </div>
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6">
        <div className="flex flex-col gap-2 p-4 bg-white/5 rounded-3xl border border-white/5 mb-4">
           <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-white/40">
              <Brain size={12} className="text-[#d4ff00]" /> Context Awareness
           </div>
           <p className="text-[10px] text-white/60 font-medium">Tracking: {userProfile?.goal} • {userProfile?.fitnessLevel} • Day {userProfile?.streak || 0}</p>
        </div>

        {messages.map((m, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex ${m.role === 'ai' ? 'justify-start' : 'justify-end'}`}
          >
            <div className={`max-w-[90%] p-5 rounded-[2rem] text-sm leading-relaxed ${
              m.role === 'ai' 
                ? 'bg-[#0a0a0a] border border-white/5 rounded-tl-none italic font-medium' 
                : 'bg-[#d4ff00] text-black rounded-tr-none font-black uppercase italic shadow-lg shadow-[#d4ff00]/10'
            }`}>
              {m.text}
            </div>
          </motion.div>
        ))}
        {isTyping && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
            <div className="bg-[#0a0a0a] p-4 rounded-2xl rounded-tl-none border border-white/5 flex gap-1.5">
              <span className="w-1.5 h-1.5 bg-[#d4ff00] rounded-full animate-bounce"></span>
              <span className="w-1.5 h-1.5 bg-[#d4ff00] rounded-full animate-bounce [animation-delay:0.2s]"></span>
              <span className="w-1.5 h-1.5 bg-[#d4ff00] rounded-full animate-bounce [animation-delay:0.4s]"></span>
            </div>
          </motion.div>
        )}
      </div>

      <div className="p-6 bg-[#050505] border-t border-white/5 backdrop-blur-md">
        <div className="relative group">
          <input 
            type="text" 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Input Request..." 
            className="w-full bg-[#0a0a0a] border border-white/10 rounded-2xl py-4 px-6 pr-14 text-sm font-bold focus:outline-none focus:border-[#d4ff00]/50 transition-all group-hover:border-white/20"
          />
          <button 
            onClick={handleSend}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2.5 bg-[#d4ff00] text-black rounded-xl shadow-xl hover:scale-105 active:scale-95 transition-all"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};