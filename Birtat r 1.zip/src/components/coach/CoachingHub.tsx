import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BrainCircuit, User, Sparkles, MessageSquare, PhoneCall, Calendar, ChevronRight, Star, ShieldCheck } from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { AICoach } from './AICoach';
import { UserProfile } from '../../lib/types';
import { toast } from 'sonner';

export const CoachingHub: React.FC<{ userProfile: UserProfile | null }> = ({ userProfile }) => {
  const { t } = useLanguage();
  const [mode, setMode] = useState<'hub' | 'ai'>('hub');

  const handleHumanCoachRequest = () => {
    toast.success("Request sent! A certified coach will contact you within 24 hours.");
  };

  if (mode === 'ai') {
    return (
      <div className="relative h-screen">
        <button 
          onClick={() => setMode('hub')} 
          className="absolute top-6 left-4 z-50 p-2 bg-black/40 backdrop-blur-md border border-white/10 rounded-full text-white/60 hover:text-white transition-colors"
        >
          <ChevronRight className="rotate-180" size={20} />
        </button>
        <AICoach userProfile={userProfile} />
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-24 px-4 pt-6">
      <header>
        <h1 className="text-3xl font-extrabold tracking-tight text-[#d4ff00]">{t('coachingHub')}</h1>
        <p className="text-muted-foreground text-sm">Professional guidance for every step of your journey.</p>
      </header>

      <div className="space-y-6">
        <motion.div 
          whileHover={{ y: -4 }}
          onClick={() => setMode('ai')}
        >
          <Card className="bg-gradient-to-br from-[#d4ff00]/20 to-secondary/30 border-[#d4ff00]/20 overflow-hidden cursor-pointer group relative">
            <div className="absolute top-0 right-0 p-8 opacity-10 transform translate-x-4 -translate-y-4">
              <BrainCircuit size={120} />
            </div>
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-3 bg-[#d4ff00] text-black rounded-2xl shadow-lg shadow-[#d4ff00]/20">
                  <BrainCircuit size={24} />
                </div>
                <div>
                  <h2 className="text-xl font-black italic uppercase">AI COACH ATLAS</h2>
                  <Badge className="bg-green-500/20 text-green-500 border-none">AVAILABLE 24/7</Badge>
                </div>
              </div>
              <p className="text-sm text-white/70 mb-6 max-w-[80%]">
                {t('aiDescription')} Instant answers for training, nutrition, and lifestyle optimization.
              </p>
              <Button className="w-full h-12 bg-[#d4ff00] hover:bg-[#c4eb00] text-black font-black rounded-xl flex items-center justify-between px-6">
                CHAT NOW
                <ChevronRight size={18} />
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div whileHover={{ y: -4 }}>
          <Card className="bg-secondary/20 border-white/5 overflow-hidden group">
            <div className="h-40 relative">
               <img src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/coach-human-avatar-dec2ce4e-1775838960736.webp" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" alt="Human Coach" />
               <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent" />
               <div className="absolute bottom-3 left-4">
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-black italic uppercase text-white">{t('humanCoach')}</h2>
                    <ShieldCheck size={18} className="text-blue-500" />
                  </div>
               </div>
            </div>
            <CardContent className="p-6">
              <p className="text-sm text-white/70 mb-6">
                {t('humanDescription')} Get 1-on-1 personalized feedback, weekly video calls, and tailored adjustments.
              </p>

              <div className="grid grid-cols-2 gap-3 mb-6">
                 <div className="bg-white/5 p-3 rounded-xl border border-white/5">
                    <div className="flex items-center gap-2 mb-1">
                       <MessageSquare size={14} className="text-[#d4ff00]" />
                       <span className="text-[10px] font-bold text-white uppercase">Weekly Check-ins</span>
                    </div>
                    <p className="text-[9px] text-muted-foreground">In-depth progress reviews</p>
                 </div>
                 <div className="bg-white/5 p-3 rounded-xl border border-white/5">
                    <div className="flex items-center gap-2 mb-1">
                       <PhoneCall size={14} className="text-[#d4ff00]" />
                       <span className="text-[10px] font-bold text-white uppercase">Priority Support</span>
                    </div>
                    <p className="text-[9px] text-muted-foreground">Direct access to pros</p>
                 </div>
              </div>

              <Button 
                onClick={handleHumanCoachRequest}
                variant="outline" 
                className="w-full h-12 border-[#d4ff00]/30 text-[#d4ff00] hover:bg-[#d4ff00]/10 font-black rounded-xl"
              >
                {t('requestCoach')}
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        <Card className="bg-blue-500/5 border-blue-500/20">
           <CardContent className="p-4 flex items-center gap-4">
              <div className="p-3 bg-blue-500 rounded-2xl text-white">
                 <Calendar size={24} />
              </div>
              <div className="flex-1">
                 <h4 className="text-sm font-bold text-blue-500">COACHING SESSIONS</h4>
                 <p className="text-[10px] text-muted-foreground">Manage your scheduled calls and past session notes here.</p>
              </div>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                 <ChevronRight size={18} />
              </Button>
           </CardContent>
        </Card>
      </div>
    </div>
  );
};