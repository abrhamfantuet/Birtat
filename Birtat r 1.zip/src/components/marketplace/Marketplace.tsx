import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, Star, Heart, ChevronRight, Ruler, Plus, ArrowLeft, Camera, CreditCard, LayoutGrid } from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { UserProfile, Product } from '../../lib/types';
import { toast } from 'sonner';

export const Marketplace: React.FC<{ userProfile: UserProfile | null }> = ({ userProfile }) => {
  const { t } = useLanguage();
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isVirtualTryOn, setIsVirtualTryOn] = useState(false);
  const [activeImgIdx, setActiveImgIdx] = useState(0);

  const products: Product[] = [
    { 
      id: '1', 
      name: 'Birtat Performance Tee', 
      price: 1250, 
      rating: 4.9, 
      image: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/ethiopian-gym-wear---apparel-1-59908463-1775582315387.webp', 
      category: 'Apparel',
      description: 'High-quality moisture-wicking fabric with traditional Ethiopian-inspired accents. Perfect for high-intensity training.'
    },
    { 
      id: '2', 
      name: 'Hypertrophy Grips', 
      price: 850, 
      rating: 4.8, 
      image: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/gymwear-set-dfe320c3-1775466032047.webp', 
      category: 'Equipment',
      description: 'Ergonomic grips to maximize your mind-muscle connection and prevent grip fatigue.'
    },
    { 
      id: '3', 
      name: 'Birtat Whey Protein', 
      price: 4500, 
      rating: 5.0, 
      image: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/ethiopian-supplements---protein-367da94f-1775582316711.webp', 
      category: 'Supplements',
      description: 'Premium quality whey isolate with complete amino acid profile for maximum recovery.'
    },
  ];

  const handleCheckout = (method: 'telebirr' | 'mpesa') => {
    toast.success(`Redirecting to ${method === 'telebirr' ? 'Telebirr' : 'M-Pesa'} payment...`);
  };

  if (selectedProduct) {
    const gallery = [selectedProduct.image, products[1].image, products[2].image];
    
    return (
      <div className="min-h-screen bg-background pb-32">
        <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md p-4 flex items-center gap-4 border-b border-white/5">
          <button onClick={() => setSelectedProduct(null)} className="p-2 -ml-2 text-muted-foreground hover:text-white">
            <ArrowLeft size={24} />
          </button>
          <h2 className="font-bold truncate text-sm uppercase tracking-widest">{selectedProduct.name}</h2>
        </header>

        <div className="p-4 space-y-6">
          <div className="space-y-4">
            <div className="aspect-square rounded-3xl overflow-hidden bg-secondary relative">
               <motion.img 
                 key={activeImgIdx}
                 initial={{ opacity: 0 }}
                 animate={{ opacity: 1 }}
                 src={isVirtualTryOn && userProfile?.selfieUrl ? userProfile.selfieUrl : gallery[activeImgIdx]} 
                 className="w-full h-full object-cover transition-all" 
                 alt={selectedProduct.name} 
               />
               {isVirtualTryOn && (
                 <div className="absolute inset-0 bg-black/40 flex items-center justify-center pointer-events-none">
                   <Badge className="bg-[#d4ff00] text-black border-none font-black animate-pulse">AI VIRTUAL TRY-ON ACTIVE</Badge>
                 </div>
               )}
            </div>

            {/* Instagram Style Nanobar Gallery */}
            <div className="flex gap-2 overflow-x-auto no-scrollbar px-1">
               {gallery.map((img, i) => (
                 <button 
                   key={i} 
                   onClick={() => setActiveImgIdx(i)}
                   className={`w-16 h-16 rounded-xl overflow-hidden border-2 flex-shrink-0 transition-all ${activeImgIdx === i ? 'border-[#d4ff00] scale-105' : 'border-white/5 opacity-50'}`}
                 >
                    <img src={img} className="w-full h-full object-cover" alt="Gallery" />
                 </button>
               ))}
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <Badge className="bg-[#d4ff00]/10 text-[#d4ff00] border-none mb-2">{selectedProduct.category}</Badge>
                <h3 className="text-2xl font-black italic uppercase tracking-tighter">{selectedProduct.name}</h3>
              </div>
              <p className="text-2xl font-black text-[#d4ff00]">{selectedProduct.price} {t('currency')}</p>
            </div>

            <div className="flex items-center gap-4">
               <div className="flex items-center gap-1 bg-white/5 px-2 py-1 rounded-lg">
                 <Star size={14} className="text-yellow-500 fill-yellow-500" />
                 <span className="font-bold text-sm">{selectedProduct.rating}</span>
               </div>
               <span className="text-muted-foreground text-xs font-bold">124 VERIFIED REVIEWS</span>
            </div>

            <p className="text-sm text-muted-foreground leading-relaxed">
              {selectedProduct.description}
            </p>

            <Card className="bg-[#d4ff00]/5 border-[#d4ff00]/20">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <h4 className="font-black text-[10px] uppercase tracking-widest text-[#d4ff00] mb-1">{t('sizeRecommendation')}</h4>
                  <p className="text-xs font-medium">Based on your {userProfile?.chest}cm chest, we recommend <b className="text-white">Size L</b></p>
                </div>
                <Ruler size={24} className="text-[#d4ff00] opacity-30" />
              </CardContent>
            </Card>

            <div className="grid grid-cols-2 gap-3 pt-4">
               <Button 
                 onClick={() => setIsVirtualTryOn(!isVirtualTryOn)}
                 variant="outline" 
                 className="h-14 rounded-2xl border-white/10 bg-white/5 font-black uppercase text-xs tracking-widest hover:bg-[#d4ff00]/10 hover:text-[#d4ff00]"
               >
                 <Camera size={18} className="mr-2" /> {t('virtualTryOn')}
               </Button>
               <Button className="h-14 rounded-2xl bg-[#d4ff00] text-black font-black uppercase text-xs tracking-widest shadow-lg shadow-[#d4ff00]/20">
                 Add to Cart
               </Button>
            </div>

            <div className="space-y-3 pt-6 border-t border-white/5">
               <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">SECURE CHECKOUT</p>
               <div className="flex gap-3">
                  <Button onClick={() => handleCheckout('telebirr')} className="flex-1 h-12 rounded-xl bg-[#2b71b9] hover:bg-[#2b71b9]/90 text-white font-black text-xs tracking-widest">
                    TELEBIRR
                  </Button>
                  <Button onClick={() => handleCheckout('mpesa')} className="flex-1 h-12 rounded-xl bg-[#c5322b] hover:bg-[#c5322b]/90 text-white font-black text-xs tracking-widest">
                    M-PESA
                  </Button>
               </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-24 pt-4 px-4">
      <header>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold uppercase tracking-tight">{t('marketplace')}</h2>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="text-muted-foreground">
               <LayoutGrid size={20} />
            </Button>
            <div className="relative">
              <ShoppingCart size={24} className="text-muted-foreground" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#d4ff00] text-[10px] font-black text-black flex items-center justify-center rounded-full">2</span>
            </div>
          </div>
        </div>
      </header>

      <section>
        <Card className="bg-gradient-to-br from-[#d4ff00] to-[#c4eb00] text-black border-none overflow-hidden relative shadow-xl shadow-[#d4ff00]/10">
          <CardContent className="p-6">
            <div className="relative z-10 space-y-2">
              <Badge className="bg-black/20 text-black border-none font-black text-[9px] uppercase tracking-tighter">PRO RECOMMENDATION</Badge>
              <h2 className="text-2xl font-black italic uppercase leading-none">FIT CHECK AI</h2>
              <p className="text-[11px] font-bold opacity-80 max-w-[180px]">Size L fits your {userProfile?.chest}cm chest best.</p>
              <Button size="sm" variant="outline" className="mt-2 border-black/40 text-black font-black text-[10px] uppercase hover:bg-black/10">
                <Ruler size={12} className="mr-1" /> Update Stats
              </Button>
            </div>
            <div className="absolute top-0 right-0 w-32 h-full opacity-10 transform translate-x-4">
              <Ruler size={160} className="rotate-12" />
            </div>
          </CardContent>
        </Card>
      </section>

      <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
        {['All', 'Apparel', 'Equipment', 'Supplements'].map((cat, i) => (
          <button 
            key={cat} 
            className={`whitespace-nowrap px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${i === 0 ? 'bg-white text-black' : 'bg-secondary/40 text-muted-foreground border border-white/5 hover:border-white/20'}`}
          >
            {cat}
          </button>
        ))}
      </div>

      <section className="grid grid-cols-2 gap-4">
        {products.map((p, idx) => (
          <motion.div
            key={p.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: idx * 0.1 }}
            onClick={() => setSelectedProduct(p)}
          >
            <div className="group cursor-pointer">
              <div className="aspect-[4/5] rounded-3xl bg-secondary/30 overflow-hidden relative border border-white/5 group-hover:border-[#d4ff00]/30 transition-all">
                <img src={p.image} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt={p.name} />
                <button className="absolute top-3 right-3 p-2 rounded-full bg-black/40 backdrop-blur-md text-white hover:text-red-500 transition-colors border border-white/10">
                  <Heart size={14} />
                </button>
              </div>
              <div className="mt-3 space-y-1 px-1">
                <div className="flex items-center gap-1">
                  <Star size={10} className="text-[#d4ff00] fill-[#d4ff00]" />
                  <span className="text-[9px] font-black">{p.rating}</span>
                </div>
                <h4 className="font-bold text-xs truncate uppercase">{p.name}</h4>
                <div className="flex items-center justify-between">
                  <span className="text-[#d4ff00] font-black text-sm">{p.price} <small className="text-[9px]">{t('currency')}</small></span>
                  <button className="w-7 h-7 rounded-full bg-white/5 flex items-center justify-center hover:bg-[#d4ff00] hover:text-black transition-all border border-white/5">
                    <Plus size={14} />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </section>
    </div>
  );
};