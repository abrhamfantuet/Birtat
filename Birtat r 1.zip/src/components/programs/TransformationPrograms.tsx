import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Clock, Target, ChevronRight, Lock, Flame, Zap } from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import { toast } from 'sonner';

export const TransformationPrograms: React.FC = () => {
  const { t } = useLanguage();

  const programs = [
    { 
      id: '21day', 
      title: '21-Day Shred', 
      duration: '21 Days', 
      level: 'Intermediate', 
      intensity: 'High', 
      image: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/programs-hero-059aed59-1775838964116.webp',
      locked: false,
      progress: 65,
      day: 14
    },
    { 
      id: '30day', 
      title: 'Mass Evolution', 
      duration: '30 Days', 
      level: 'Advanced', 
      intensity: 'Extreme', 
      image: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/male-workout-hero-c24fdb17-1775586067747.webp',
      locked: true,
      progress: 0
    },
    { 
      id: '60day', 
      title: 'Pure Discipline', 
      duration: '60 Days', 
      level: 'Beginner', 
      intensity: 'Moderate', 
      image: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/community-hero-28b9e2f3-1775838956796.webp',
      locked: true,
      progress: 0
    }
  ];

  const handleProgramClick = (p: any) => {
    if (p.locked) {
      toast.error("This program is locked. Complete the 21-Day Shred or upgrade to PRO!");
    } else {
      toast.success(`Opening ${p.title} - Day ${p.day}`);
    }
  };

  return (
    <div className="space-y-6 pb-24 px-4 pt-6">
      <header>
        <h1 className="text-3xl font-extrabold tracking-tight text-[#d4ff00]">{t('challenges')}</h1>
        <p className="text-muted-foreground text-sm">Commit to a structured transformation path.</p>
      </header>

      <div className="space-y-6">
        {programs.map((p, idx) => (
          <motion.div
            key={p.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            onClick={() => handleProgramClick(p)}
          >
            <Card className={`group cursor-pointer overflow-hidden border-white/5 relative bg-secondary/20 transition-all ${!p.locked && 'hover:border-[#d4ff00]/30 shadow-lg hover:shadow-[#d4ff00]/5'}`}>
              <div className="h-40 relative">
                <img src={p.image} className={`w-full h-full object-cover transition-transform duration-700 ${!p.locked && 'group-hover:scale-105'} ${p.locked && 'grayscale brightness-50'}`} alt={p.title} />
                <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent" />
                
                <div className="absolute top-3 right-3">
                  {p.locked ? (
                    <div className="bg-black/60 backdrop-blur-md p-2 rounded-full">
                      <Lock size={16} className="text-white/40" />
                    </div>
                  ) : (
                    <Badge className="bg-[#d4ff00] text-black border-none font-black">ACTIVE</Badge>
                  )}
                </div>

                <div className="absolute bottom-3 left-3">
                  <h3 className="text-xl font-black text-white uppercase tracking-tighter italic">{p.title}</h3>
                </div>
              </div>

              <CardContent className="p-4">
                <div className="flex justify-between items-center mb-4">
                   <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1 text-[10px] font-bold text-muted-foreground uppercase">
                        <Clock size={12} className="text-[#d4ff00]" /> {p.duration}
                      </div>
                      <div className="flex items-center gap-1 text-[10px] font-bold text-muted-foreground uppercase">
                        <Target size={12} className="text-[#d4ff00]" /> {p.level}
                      </div>
                   </div>
                   <div className="flex items-center gap-1 text-[10px] font-bold text-[#d4ff00] uppercase">
                      <Zap size={12} /> {p.intensity}
                   </div>
                </div>

                {!p.locked && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-[10px] font-bold uppercase">
                      <span className="text-muted-foreground">Day {p.day} of {p.duration.split(' ')[0]}</span>
                      <span className="text-[#d4ff00]">{p.progress}% Complete</span>
                    </div>
                    <Progress value={p.progress} className="h-1.5 bg-white/5" />
                  </div>
                )}
                
                {p.locked && (
                   <Button variant="outline" className="w-full h-10 border-white/10 text-white/40 font-bold text-xs">
                      UNLOCK PROGRAM
                   </Button>
                )}
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
};