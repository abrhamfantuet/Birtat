import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calculator, Utensils, Flame, Apple, Info, Plus, Camera, Image as ImageIcon, Loader2, Sparkles } from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { Card, CardContent } from '../ui/card';
import { Input } from '../ui/input';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import { UserProfile } from '../../lib/types';
import { toast } from 'sonner';
import { MealPlanner } from '../mealplan/MealPlanner';

export const NutritionDashboard: React.FC<{ userProfile: UserProfile | null }> = ({ userProfile }) => {
  const { t } = useLanguage();
  const [weight, setWeight] = useState(userProfile?.weight || 82);
  const [calories, setCalories] = useState(userProfile?.goal === 'fatLoss' ? 2200 : 2850);
  const [consumed, setConsumed] = useState(1240);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [view, setView] = useState<'stats' | 'mealPlan'>('stats');

  const macros = [
    { label: 'Protein', current: 120, target: userProfile?.goal === 'hypertrophy' ? 200 : 160, color: 'bg-[#d4ff00]' },
    { label: 'Carbs', current: 150, target: 350, color: 'bg-blue-500' },
    { label: 'Fats', current: 40, target: 75, color: 'bg-yellow-500' },
  ];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (re) => {
        setCapturedImage(re.target?.result as string);
        analyzeFood();
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeFood = () => {
    setIsAnalyzing(true);
    setTimeout(() => {
      setIsAnalyzing(false);
      setConsumed(prev => prev + 450);
      toast.success("AI Analysis: 450 kcal detected (35g Protein, 50g Carbs, 10g Fat)");
      setCapturedImage(null);
    }, 2500);
  };

  return (
    <div className="space-y-6 pb-24 px-4 pt-6">
      {view === 'mealPlan' ? (
        <div className="relative animate-in fade-in duration-300">
           <button onClick={() => setView('stats')} className="absolute top-6 left-0 z-50 p-2 bg-black/40 backdrop-blur-md rounded-full text-white/60 hover:text-white transition-colors">
              <Plus className="rotate-45" size={20} />
           </button>
           <MealPlanner userProfile={userProfile} />
        </div>
      ) : (
        <div className="space-y-6 animate-in fade-in duration-300">
          <header>
            <h1 className="text-3xl font-extrabold tracking-tight text-[#d4ff00]">{t('nutrition')}</h1>
            <p className="text-muted-foreground text-sm">Fuel your {userProfile?.goal || 'fitness'} with AI-powered logging.</p>
            
            <div className="flex gap-4 mt-4">
               <button 
                 onClick={() => setView('stats')} 
                 className={`flex-1 py-2 text-xs font-black uppercase tracking-widest border-b-2 transition-colors ${(view as string) === 'stats' ? 'border-[#d4ff00] text-[#d4ff00]' : 'border-transparent text-muted-foreground'}`}
               >
                  {t('analytics')}
               </button>
               <button 
                 onClick={() => setView('mealPlan')} 
                 className={`flex-1 py-2 text-xs font-black uppercase tracking-widest border-b-2 transition-colors ${(view as string) === 'mealPlan' ? 'border-[#d4ff00] text-[#d4ff00]' : 'border-transparent text-muted-foreground'}`}
               >
                  {t('mealPlan')}
               </button>
            </div>
          </header>

          <div className="grid grid-cols-2 gap-4">
            <Card className="bg-secondary/30 border-white/5">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Calculator size={16} className="text-[#d4ff00]" />
                  <span className="text-xs font-bold uppercase tracking-wider">{t('tdeeCalculator')}</span>
                </div>
                <div className="space-y-3">
                  <div>
                    <label className="text-[10px] text-muted-foreground uppercase">{t('currentWeight')}</label>
                    <div className="flex items-end gap-1">
                      <Input type="number" value={weight} onChange={(e) => setWeight(Number(e.target.value))} className="h-8 p-0 bg-transparent border-none text-lg font-bold w-12" />
                      <span className="text-xs text-muted-foreground mb-1">kg</span>
                    </div>
                  </div>
                  <div className="pt-1 border-t border-white/5">
                    <span className="text-[10px] text-muted-foreground uppercase">Target</span>
                    <p className="font-bold text-[#d4ff00]">{calories} kcal</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#d4ff00] border-none shadow-xl shadow-[#d4ff00]/20">
              <CardContent className="p-4 text-black">
                <div className="flex items-center gap-2 mb-2">
                  <Flame size={16} />
                  <span className="text-xs font-bold uppercase tracking-wider">Remaining</span>
                </div>
                <p className="text-3xl font-black">{calories - consumed}</p>
                <p className="text-[10px] font-bold opacity-70">kcal left today</p>
                <Progress value={(consumed / calories) * 100} className="h-1.5 mt-4 bg-black/20" />
              </CardContent>
            </Card>
          </div>

          <section className="space-y-4">
            <h3 className="font-bold flex items-center gap-2 text-white">
              <Utensils size={18} className="text-[#d4ff00]" /> Daily Macros
            </h3>
            <div className="space-y-4">
              {macros.map((m) => (
                <div key={m.label} className="space-y-1.5">
                  <div className="flex justify-between text-[11px] font-bold uppercase tracking-wider">
                    <span>{m.label}</span>
                    <span className="text-muted-foreground">{m.current}g / {m.target}g</span>
                  </div>
                  <Progress value={(m.current / m.target) * 100} className={`h-2 ${m.color}`} />
                </div>
              ))}
            </div>
          </section>

          <section className="space-y-4">
            <h3 className="font-bold flex items-center gap-2 text-white">
              <Camera size={18} className="text-[#d4ff00]" /> AI Food Logger
            </h3>
            <Card className="bg-secondary/20 border-white/5 overflow-hidden border-dashed border-2">
              <CardContent className="p-0">
                {isAnalyzing ? (
                  <div className="h-48 flex flex-col items-center justify-center gap-3 bg-black/40">
                    <Loader2 className="animate-spin text-[#d4ff00]" size={32} />
                    <p className="text-xs font-bold text-[#d4ff00] animate-pulse">Analyzing nutritional density...</p>
                  </div>
                ) : capturedImage ? (
                  <div className="h-48 relative">
                    <img src={capturedImage} className="w-full h-full object-cover" alt="food" />
                  </div>
                ) : (
                  <div className="h-48 flex flex-col items-center justify-center gap-4 group">
                    <div className="flex gap-4">
                       <label className="cursor-pointer p-4 bg-white/5 rounded-2xl hover:bg-[#d4ff00]/10 transition-colors">
                          <Camera size={24} className="text-[#d4ff00]" />
                          <input type="file" accept="image/*" capture="environment" className="hidden" onChange={handleImageUpload} />
                       </label>
                       <label className="cursor-pointer p-4 bg-white/5 rounded-2xl hover:bg-[#d4ff00]/10 transition-colors">
                          <ImageIcon size={24} className="text-[#d4ff00]" />
                          <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                       </label>
                    </div>
                    <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">Snap or Upload for AI Calculation</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </section>
        </div>
      )}
    </div>
  );
};