import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bookmark, Shield, ArrowRight, History, Zap, Lock } from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { CommunityPost } from './CommunityFeed';
import { PostCard } from './PostCard';
import { Button } from '../ui/button';

interface CommunityVaultProps {
  savedPosts: CommunityPost[];
  onToggleSave: (id: string) => void;
}

export const CommunityVault: React.FC<CommunityVaultProps> = ({ savedPosts, onToggleSave }) => {
  const { t } = useLanguage();

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.98 }}
      className="space-y-10"
    >
      {/* Vault Header */}
      <div className="py-10 border-b border-white/5 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-[0_0_30px_rgba(255,255,255,0.1)]">
                <Lock className="text-black" size={24} strokeWidth={2.5} />
              </div>
              <div className="flex flex-col">
                 <h2 className="text-3xl md:text-5xl font-black italic tracking-tighter uppercase">
                  {t('communityVault')}
                </h2>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-[#d4ff00] rounded-full animate-pulse" />
                  <p className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.3em]">Personal Strategic Archive</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4 bg-zinc-900/50 backdrop-blur-md px-5 py-3 rounded-2xl border border-white/5">
            <div className="flex flex-col">
              <span className="text-[10px] text-zinc-600 font-black uppercase tracking-widest">Stored Items</span>
              <span className="text-xl font-black italic text-[#d4ff00]">{savedPosts.length.toString().padStart(2, '0')}</span>
            </div>
            <div className="w-[1px] h-8 bg-white/10" />
            <div className="flex flex-col">
              <span className="text-[10px] text-zinc-600 font-black uppercase tracking-widest">Last Sync</span>
              <span className="text-sm font-black uppercase text-white">Live</span>
            </div>
          </div>
        </div>
        
        {/* Decorative Background Element */}
        <div className="absolute -right-20 -top-20 w-64 h-64 bg-white/5 rounded-full blur-[80px]" />
      </div>

      <div className="space-y-8 md:space-y-12">
        {savedPosts.length > 0 ? (
          <AnimatePresence mode="popLayout">
            {savedPosts.map((post, idx) => (
              <PostCard 
                key={post.id} 
                post={post} 
                index={idx} 
                isSaved={true} 
                onToggleSave={() => onToggleSave(post.id)} 
              />
            ))}
          </AnimatePresence>
        ) : (
          <div className="py-40 text-center space-y-8">
            <div className="relative inline-block">
              <motion.div 
                animate={{ 
                  scale: [1, 1.05, 1],
                  rotate: [0, 5, -5, 0]
                }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                className="w-32 h-32 bg-zinc-900/40 rounded-[2.5rem] flex items-center justify-center border-2 border-white/5 border-dashed"
              >
                <Bookmark className="text-zinc-800" size={48} />
              </motion.div>
              <div className="absolute inset-0 bg-[#d4ff00]/5 blur-3xl rounded-full z-[-1]" />
            </div>
            
            <div className="space-y-3">
              <h3 className="text-2xl font-black italic uppercase text-zinc-300 tracking-tighter">Archive Offline</h3>
              <p className="max-w-md mx-auto text-zinc-500 text-xs font-bold uppercase tracking-[0.15em] leading-relaxed px-4">
                Build your private library of elite insights, strategic dialogues, and data-backed transformations. All entries are encrypted locally.
              </p>
            </div>
            
            <button 
              onClick={() => window.location.reload()}
              className="flex items-center gap-3 mx-auto px-8 py-4 bg-white text-black rounded-2xl text-[10px] font-black uppercase tracking-[0.25em] hover:bg-zinc-200 transition-all active:scale-95 shadow-2xl"
            >
              Initialize Search <ArrowRight size={16} strokeWidth={3} />
            </button>
          </div>
        )}
      </div>

      {/* Security Disclaimer */}
      {savedPosts.length > 0 && (
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="mt-20 p-8 bg-zinc-950 border border-white/5 rounded-[2.5rem] relative overflow-hidden group"
        >
          <div className="flex flex-col md:flex-row items-center gap-6 relative z-10">
            <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10 group-hover:scale-110 transition-transform duration-500">
              <Shield className="text-[#d4ff00]" size={32} />
            </div>
            <div className="flex-1 text-center md:text-left">
              <h4 className="font-black italic uppercase text-lg tracking-tight text-white mb-1">Biometric-Grade Security</h4>
              <p className="text-[11px] text-zinc-500 font-bold uppercase tracking-wider leading-relaxed">
                Your personal vault is synchronized across your ecosystem using end-to-end encryption. No third-party access is permitted to your curated insights.
              </p>
            </div>
            <Button variant="outline" className="border-white/10 text-[10px] font-black uppercase tracking-widest h-12 px-6 rounded-xl hover:bg-white hover:text-black transition-all">
              Security Audit
            </Button>
          </div>
          <div className="absolute top-0 right-0 p-2 opacity-10">
             <Zap size={100} className="text-white" />
          </div>
        </motion.div>
      )}
    </motion.div>
  );
};