import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Bookmark, 
  BookmarkCheck, 
  MoreHorizontal, 
  ShieldCheck,
  ArrowUpRight
} from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { toast } from 'sonner';
import { CommunityPost } from './CommunityFeed';
import { CommentThread } from './CommentThread';

interface PostCardProps {
  post: CommunityPost;
  index: number;
  isSaved: boolean;
  onToggleSave: () => void;
}

export const PostCard: React.FC<PostCardProps> = ({ post, index, isSaved, onToggleSave }) => {
  const { t } = useLanguage();
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(post.likes);
  const [isCommentsOpen, setIsCommentsOpen] = useState(false);

  const handleLike = () => {
    setLiked(!liked);
    setLikeCount(prev => liked ? prev - 1 : prev + 1);
    if (!liked && 'vibrate' in navigator) {
      navigator.vibrate(5);
    }
  };

  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: `BIRTAT Community | ${post.category}`,
          text: post.content.substring(0, 100) + '...',
          url: window.location.href,
        });
      } else {
        await navigator.clipboard.writeText(`${window.location.href}#post-${post.id}`);
        toast.success('Frequency Synchronized', {
          description: 'Share link copied to clipboard.',
          icon: <Share2 size={16} />
        });
      }
    } catch (err) {
      console.error('Share failed:', err);
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ 
        duration: 0.6, 
        delay: index * 0.05, 
        ease: [0.23, 1, 0.32, 1] 
      }}
      className="group relative"
      id={`post-${post.id}`}
    >
      <div className="bg-zinc-900/40 border border-white/[0.03] rounded-[2.5rem] overflow-hidden transition-all duration-700 hover:border-white/10 hover:bg-zinc-900/60">
        {/* Cinematic Header */}
        <div className="p-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="relative group/avatar">
              <Avatar className="w-14 h-14 border-2 border-white/5 ring-4 ring-transparent group-hover/avatar:ring-white/5 transition-all duration-500">
                <AvatarImage src={post.user.avatar} className="object-cover" />
                <AvatarFallback className="bg-zinc-800 text-white font-black">{post.user.name[0]}</AvatarFallback>
              </Avatar>
              {post.user.isPro && (
                <div className="absolute -bottom-1 -right-1 bg-white text-black rounded-full p-1 shadow-2xl border-2 border-black">
                  <ShieldCheck size={14} strokeWidth={3} />
                </div>
              )}
            </div>
            
            <div className="flex flex-col gap-0.5">
              <div className="flex items-center gap-2">
                <h4 className="font-black text-base tracking-tight text-white/90 group-hover:text-white transition-colors">
                  {post.user.name}
                </h4>
                <Badge className="bg-white/5 hover:bg-white/10 text-[9px] h-5 border-none text-zinc-400 font-black uppercase tracking-widest px-2">
                  {post.user.level}
                </Badge>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-[10px] text-zinc-500 font-black uppercase tracking-widest">{post.time}</span>
                <span className="w-1 h-1 bg-zinc-800 rounded-full" />
                <span className="text-[10px] text-white/40 font-black uppercase tracking-widest group-hover:text-[#d4ff00]/70 transition-colors">
                  {t(post.category.toLowerCase())}
                </span>
              </div>
            </div>
          </div>
          
          <Button variant="ghost" size="icon" className="rounded-2xl text-zinc-600 hover:text-white hover:bg-white/5 transition-all">
            <MoreHorizontal size={22} />
          </Button>
        </div>

        {/* Cinematic Post Content */}
        <div className="px-7 pb-6">
          <p className="text-zinc-300 leading-[1.6] text-lg font-medium tracking-tight selection:bg-white selection:text-black">
            {post.content}
          </p>
          
          {post.tags && (
            <div className="flex flex-wrap gap-2 mt-4">
              {post.tags.map(tag => (
                <span key={tag} className="text-[9px] font-black uppercase tracking-[0.2em] text-zinc-600 hover:text-white cursor-pointer transition-colors">
                  #{tag}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* High-Impact Visuals */}
        {post.image && (
          <div className="px-6 pb-6">
            <div className="relative aspect-[16/10] rounded-[2rem] overflow-hidden border border-white/5 bg-zinc-950">
              <img 
                src={post.image} 
                alt="Community visual" 
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60" />
              
              {/* Image Overlay Label */}
              <div className="absolute bottom-6 left-6 flex items-center gap-2">
                <div className="px-3 py-1.5 bg-black/50 backdrop-blur-md rounded-full border border-white/10 flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-[#d4ff00] rounded-full animate-pulse" />
                  <span className="text-[9px] font-black uppercase tracking-widest text-white/80">RAW TRANSMISSION</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Engagement Hub */}
        <div className="px-8 py-5 border-t border-white/[0.03] bg-white/[0.01] flex items-center justify-between">
          <div className="flex items-center gap-8">
            {/* Animated Like Button */}
            <button 
              onClick={handleLike}
              className="flex items-center gap-3 group/like focus:outline-none"
            >
              <motion.div
                whileTap={{ scale: 0.7 }}
                className={`p-2.5 rounded-2xl transition-all duration-500 ${liked ? 'bg-red-500/10 text-red-500' : 'text-zinc-500 group-hover/like:bg-white/5 group-hover/like:text-white'}`}
              >
                <Heart size={24} className={liked ? 'fill-current' : ''} />
              </motion.div>
              <div className="flex flex-col">
                <AnimatePresence mode="wait">
                  <motion.span 
                    key={likeCount}
                    initial={{ y: 5, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: -5, opacity: 0 }}
                    className={`text-sm font-black italic tracking-tighter ${liked ? 'text-red-500' : 'text-zinc-400 group-hover/like:text-white'}`}
                  >
                    {likeCount.toLocaleString()}
                  </motion.span>
                </AnimatePresence>
                <span className="text-[8px] font-black uppercase tracking-widest text-zinc-600">Resonance</span>
              </div>
            </button>

            {/* Comment Button */}
            <button 
              onClick={() => setIsCommentsOpen(true)}
              className="flex items-center gap-3 group/comment focus:outline-none"
            >
              <div className="p-2.5 rounded-2xl text-zinc-500 group-hover/comment:bg-white/5 group-hover/comment:text-white transition-all duration-500">
                <MessageCircle size={24} />
              </div>
              <div className="flex flex-col text-left">
                <span className="text-sm font-black italic tracking-tighter text-zinc-400 group-hover/comment:text-white transition-colors">
                  {post.comments}
                </span>
                <span className="text-[8px] font-black uppercase tracking-widest text-zinc-600">Insights</span>
              </div>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <Button 
              onClick={onToggleSave}
              variant="ghost" 
              size="icon" 
              className={`w-12 h-12 rounded-2xl transition-all duration-500 ${isSaved ? 'text-[#d4ff00] bg-[#d4ff00]/10 border border-[#d4ff00]/20' : 'text-zinc-500 hover:text-white hover:bg-white/5'}`}
            >
              {isSaved ? <BookmarkCheck size={22} /> : <Bookmark size={22} />}
            </Button>
            <Button 
              onClick={handleShare}
              variant="ghost" 
              size="icon" 
              className="w-12 h-12 rounded-2xl text-zinc-500 hover:text-white hover:bg-white/5 transition-all duration-500"
            >
              <Share2 size={22} />
            </Button>
          </div>
        </div>
      </div>

      {/* Thread Overlay */}
      <CommentThread 
        isOpen={isCommentsOpen} 
        onClose={() => setIsCommentsOpen(false)} 
        postId={post.id} 
      />
    </motion.div>
  );
};