import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Heart, CornerDownRight, Shield, BadgeCheck } from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '../ui/sheet';

interface Comment {
  id: string;
  user: {
    name: string;
    avatar: string;
    isPro?: boolean;
  };
  content: string;
  time: string;
  likes: number;
  replies?: Comment[];
}

interface CommentThreadProps {
  isOpen: boolean;
  onClose: () => void;
  postId: string;
}

export const CommentThread: React.FC<CommentThreadProps> = ({ isOpen, onClose, postId }) => {
  const { t } = useLanguage();
  const [newComment, setNewComment] = useState('');

  // Enhanced Sample Thread
  const comments: Comment[] = [
    {
      id: 'c1',
      user: { name: 'Sami K.', avatar: 'https://i.pravatar.cc/150?u=sami' },
      content: `Absolutely critical insights on the fasting window protocol. I noticed a 15% increase in HRV when I moved my last meal to 4 hours before sleep. The data aligns with what you're saying.`,
      time: '45m ago',
      likes: 24,
      replies: [
        {
          id: 'c2',
          user: { name: 'Dr. Helen Tadesse', avatar: 'https://i.pravatar.cc/150?u=helen', isPro: true },
          content: `Excellent observation, Sami. That aligns perfectly with the melatonin-insulin interference data we're tracking in the lab. Keep documenting the HRV trends.`,
          time: '30m ago',
          likes: 12
        }
      ]
    },
    {
      id: 'c3',
      user: { name: 'Lydia M.', avatar: 'https://i.pravatar.cc/150?u=lydia' },
      content: `This transformation is legendary! What was your primary source of protein during the final 4 weeks? The definition in the delts is incredible.`,
      time: '2h ago',
      likes: 8
    }
  ];

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="right" className="w-full sm:max-w-lg bg-black border-l border-white/5 p-0 overflow-hidden flex flex-col">
        <SheetHeader className="p-6 border-b border-white/5 bg-zinc-950/50 backdrop-blur-xl sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex flex-col">
              <SheetTitle className="text-white font-black italic tracking-tighter uppercase text-2xl">
                {t('comments')}
              </SheetTitle>
              <p className="text-[9px] text-zinc-500 font-bold uppercase tracking-[0.2em]">Strategic Dialogue Hub</p>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose} className="rounded-2xl hover:bg-white/5 text-zinc-500">
              <X size={24} />
            </Button>
          </div>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto px-6 py-8 space-y-10 no-scrollbar">
          {comments.map((comment) => (
            <div key={comment.id} className="space-y-6">
              <div className="flex gap-4 group/comment">
                <div className="relative">
                  <Avatar className="w-11 h-11 border border-white/10 ring-2 ring-transparent group-hover/comment:ring-white/5 transition-all">
                    <AvatarImage src={comment.user.avatar} />
                    <AvatarFallback>{comment.user.name[0]}</AvatarFallback>
                  </Avatar>
                  {comment.user.isPro && (
                    <div className="absolute -bottom-1 -right-1 bg-white text-black rounded-full p-0.5">
                      <BadgeCheck size={12} />
                    </div>
                  )}
                </div>
                <div className="flex-1 space-y-2">
                  <div className="flex items-center justify-between">
                    <h5 className="text-sm font-black text-white/90 uppercase italic tracking-tight">{comment.user.name}</h5>
                    <span className="text-[10px] text-zinc-600 font-bold uppercase tracking-widest">{comment.time}</span>
                  </div>
                  <p className="text-zinc-400 text-sm leading-relaxed selection:bg-white selection:text-black">
                    {comment.content}
                  </p>
                  <div className="flex items-center gap-6 pt-2">
                    <button className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 hover:text-[#d4ff00] transition-colors flex items-center gap-1.5">
                      {t('reply')}
                    </button>
                    <button className="flex items-center gap-1.5 text-[10px] font-black text-zinc-600 hover:text-white transition-colors">
                      <Heart size={12} /> {comment.likes}
                    </button>
                  </div>
                </div>
              </div>

              {/* Threaded Replies */}
              {comment.replies?.map((reply) => (
                <div key={reply.id} className="ml-11 flex gap-4 border-l-2 border-zinc-900 pl-6 py-1 group/reply">
                  <div className="relative flex-shrink-0">
                    <Avatar className="w-9 h-9 border border-white/5">
                      <AvatarImage src={reply.user.avatar} />
                      <AvatarFallback>{reply.user.name[0]}</AvatarFallback>
                    </Avatar>
                    {reply.user.isPro && (
                      <div className="absolute -bottom-1 -right-1 bg-[#d4ff00] text-black rounded-full p-0.5">
                        <Shield size={10} />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 space-y-1.5">
                    <div className="flex items-center gap-2">
                       <CornerDownRight size={12} className="text-zinc-700" />
                       <h5 className="text-[12px] font-black text-white/80 uppercase tracking-tight">{reply.user.name}</h5>
                    </div>
                    <p className="text-zinc-500 text-xs leading-relaxed">{reply.content}</p>
                    <div className="flex items-center gap-4 pt-1">
                      <button className="flex items-center gap-1.5 text-[9px] font-bold text-zinc-700 hover:text-white transition-colors uppercase tracking-widest">
                        <Heart size={10} /> {reply.likes}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* Input Dock */}
        <div className="p-6 border-t border-white/5 bg-black/80 backdrop-blur-2xl">
          <div className="relative flex items-center gap-3">
            <Input 
              placeholder={t('writeSomething')}
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              className="bg-zinc-900/50 border-white/5 rounded-2xl h-14 pr-14 text-sm focus:ring-1 focus:ring-white/20 transition-all placeholder:text-zinc-700"
            />
            <Button 
              size="icon" 
              className="absolute right-1.5 top-1.5 h-11 w-11 rounded-xl bg-white text-black hover:bg-zinc-200 shadow-xl transition-all active:scale-90"
            >
              <Send size={20} />
            </Button>
          </div>
          <p className="text-[8px] text-center text-zinc-700 font-bold uppercase tracking-[0.3em] mt-4">
            ENCRYPTED NODE TRANSMISSION
          </p>
        </div>
      </SheetContent>
    </Sheet>
  );
};