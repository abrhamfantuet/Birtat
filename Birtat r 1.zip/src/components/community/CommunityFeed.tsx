import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence, LayoutGroup } from 'framer-motion';
import { 
  Search, 
  PlusCircle, 
  Bookmark, 
  Zap,
  HelpCircle,
  TrendingUp,
  History,
  Shield,
  X,
  Plus
} from 'lucide-react';
import { useLanguage } from '../LanguageSwitcher';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { PostCard } from './PostCard';
import { CommunityVault } from './CommunityVault';
import { toast } from 'sonner';

export interface CommunityPost {
  id: string;
  user: {
    name: string;
    avatar: string;
    level: string;
    isPro?: boolean;
  };
  content: string;
  image?: string;
  likes: number;
  comments: number;
  time: string;
  category: 'Motivation' | 'Questions' | 'Transformations';
  tags: string[];
}

export const CommunityFeed: React.FC = () => {
  const { t } = useLanguage();
  const [activeView, setActiveView] = useState<'feed' | 'vault'>('feed');
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'Motivation' | 'Questions' | 'Transformations'>('All');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [savedPostIds, setSavedPostIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('birtat_saved_posts');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('birtat_saved_posts', JSON.stringify(savedPostIds));
  }, [savedPostIds]);

  // Enhanced Sample Data with generated images
  const posts: CommunityPost[] = useMemo(() => [
    {
      id: '1',
      user: { name: 'Dawit Bekele', avatar: 'https://i.pravatar.cc/150?u=dawit', level: 'Gold', isPro: true },
      content: `True strength is built in the moments when you want to quit but choose to endure. Your mindset is the architect of your reality. Transcend the ordinary and embrace the grind. This is where champions are forged.`,
      image: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/motivation-hero-bef91cf4-1776713489874.webp',
      likes: 1240,
      comments: 48,
      time: '1h ago',
      category: 'Motivation',
      tags: ['Mindset', 'Discipline']
    },
    {
      id: '2',
      user: { name: 'Dr. Helen Tadesse', avatar: 'https://i.pravatar.cc/150?u=helen', level: 'Platinum' },
      content: `Strategic Question: How do you optimize your circadian rhythm for peak athletic performance during the fasting window? I've been experimenting with low-intensity steady state cardio at 5 AM. Let's discuss the data-backed protocols.`,
      image: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/questions-hero-962c539d-1776713490072.webp',
      likes: 89,
      comments: 156,
      time: '3h ago',
      category: 'Questions',
      tags: ['Strategy', 'Biohacking']
    },
    {
      id: '3',
      user: { name: 'Bereket G.', avatar: 'https://i.pravatar.cc/150?u=bereket', level: 'Diamond', isPro: true },
      content: `90-Day Evolution. From 18% body fat to 9% while increasing lean tissue mass by 3.2kg. The BIRTAT ecosystem provided the precision I needed for this transformation. Metrics don't lie.`,
      image: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/transformations-hero-4c91223a-1776713493811.webp',
      likes: 2450,
      comments: 112,
      time: '5h ago',
      category: 'Transformations',
      tags: ['Evolution', 'Data']
    },
    {
      id: '4',
      user: { name: 'Lydia M.', avatar: 'https://i.pravatar.cc/150?u=lydia', level: 'Silver' },
      content: `Question: What are the best local Ethiopian grains to substitute for quinoa in a high-protein post-workout meal? Looking for sustainable, locally sourced options.`,
      likes: 42,
      comments: 15,
      time: '6h ago',
      category: 'Questions',
      tags: ['Nutrition', 'Local']
    }
  ], []);

  const filteredPosts = useMemo(() => {
    return posts.filter(post => {
      const matchesCategory = selectedCategory === 'All' || post.category === selectedCategory;
      const matchesSearch = post.content.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            post.user.name.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [posts, selectedCategory, searchQuery]);

  const handleToggleSave = (id: string) => {
    setSavedPostIds(prev => {
      const isSaving = !prev.includes(id);
      if (isSaving) {
        toast.success('Archived to Vault', {
          description: 'Post saved for future strategic reference.',
          icon: <Bookmark size={16} className="text-[#d4ff00]" />
        });
        return [...prev, id];
      } else {
        toast.info('Removed from Vault');
        return prev.filter(pId => pId !== id);
      }
    });
  };

  const categories = [
    { id: 'All', icon: <History size={16} />, label: t('allCategories') },
    { id: 'Motivation', icon: <Zap size={16} />, label: t('motivation') },
    { id: 'Questions', icon: <HelpCircle size={16} />, label: t('questions') },
    { id: 'Transformations', icon: <TrendingUp size={16} />, label: t('transformations') },
  ];

  const getCategoryTheme = () => {
    switch(selectedCategory) {
      case 'Motivation': return { color: '#d4ff00', label: t('motivationSubtitle') };
      case 'Questions': return { color: '#3b82f6', label: t('questionsSubtitle') };
      case 'Transformations': return { color: '#f43f5e', label: t('transformationsSubtitle') };
      default: return { color: '#ffffff', label: 'ELITE COMMUNITY ECOSYSTEM' };
    }
  };

  const theme = getCategoryTheme();

  return (
    <div className="min-h-screen bg-black text-white selection:bg-[#d4ff00] selection:text-black pb-24 font-sans antialiased">
      {/* Cinematic Header / Hero Section */}
      <header className="sticky top-0 z-50 bg-black/95 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-4 cursor-pointer"
            onClick={() => setActiveView('feed')}
          >
            <div className="relative">
              <div className="w-11 h-11 bg-white rounded-2xl rotate-6 flex items-center justify-center transition-transform hover:rotate-0">
                <Shield className="text-black" size={22} fill="currentColor" />
              </div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#d4ff00] rounded-full animate-pulse shadow-[0_0_10px_#d4ff00]" />
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tighter uppercase italic leading-none">
                {t('community')}
              </h1>
              <p className="text-[9px] text-zinc-500 font-bold uppercase tracking-[0.3em] mt-1">
                LIVE MVP NODE
              </p>
            </div>
          </motion.div>

          <div className="flex items-center gap-1.5 md:gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="rounded-full hover:bg-white/10 text-zinc-400 hover:text-white"
            >
              {isSearchOpen ? <X size={20} /> : <Search size={20} />}
            </Button>
            
            <Button 
              onClick={() => setActiveView(activeView === 'feed' ? 'vault' : 'feed')}
              variant="ghost" 
              size="icon" 
              className={`rounded-full transition-all ${activeView === 'vault' ? 'text-[#d4ff00] bg-[#d4ff00]/10' : 'text-zinc-400 hover:bg-white/10 hover:text-white'}`}
            >
              <Bookmark size={20} />
            </Button>

            <Button className="bg-white text-black hover:bg-zinc-200 rounded-2xl h-11 px-4 md:px-6 font-black italic uppercase tracking-tighter text-sm flex items-center gap-2 transition-all active:scale-95">
              <Plus size={20} strokeWidth={3} />
              <span className="hidden sm:inline">{t('post')}</span>
            </Button>
          </div>
        </div>

        {/* Dynamic Search Bar */}
        <AnimatePresence>
          {isSearchOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="max-w-4xl mx-auto px-4 pb-4 overflow-hidden"
            >
              <div className="relative group">
                <Input 
                  autoFocus
                  placeholder={t('writeSomething')} 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-zinc-900/50 border-white/5 rounded-2xl h-14 pl-14 text-lg font-medium focus:ring-1 focus:ring-white/20 transition-all placeholder:text-zinc-600"
                />
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-zinc-600 group-focus-within:text-white transition-colors" size={22} />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Experience */}
      <main className="max-w-4xl mx-auto px-4 mt-8">
        {activeView === 'feed' ? (
          <div className="space-y-10">
            {/* Cinematic Category Toggles */}
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-2 -mx-4 px-4">
              <LayoutGroup id="community-tabs">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id as any)}
                    className={`relative px-6 py-3 rounded-2xl text-[10px] md:text-xs font-black uppercase tracking-[0.15em] transition-all flex items-center gap-2.5 whitespace-nowrap ${
                      selectedCategory === cat.id ? 'text-black' : 'text-zinc-500 hover:text-white'
                    }`}
                  >
                    {selectedCategory === cat.id && (
                      <motion.div
                        layoutId="active-cat-bg"
                        className="absolute inset-0 bg-white rounded-2xl z-0 shadow-[0_10px_20px_-5px_rgba(255,255,255,0.2)]"
                        transition={{ type: "spring", bounce: 0.15, duration: 0.5 }}
                      />
                    )}
                    <span className="relative z-10">{cat.icon}</span>
                    <span className="relative z-10">{cat.label}</span>
                  </button>
                ))}
              </LayoutGroup>
            </div>

            {/* Category Context */}
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedCategory}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="relative py-4"
              >
                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-3">
                    <h2 className="text-4xl md:text-6xl font-black tracking-tighter uppercase italic">
                      {selectedCategory === 'All' ? t('community') : t(selectedCategory.toLowerCase())}
                    </h2>
                    <div className="h-[2px] flex-1 bg-gradient-to-r from-white/20 to-transparent mt-4" />
                  </div>
                  <p className="text-xs md:text-sm font-black uppercase tracking-[0.25em] text-zinc-500 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: theme.color }} />
                    {theme.label}
                  </p>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Content Feed */}
            <div className="space-y-8 md:space-y-12">
              <AnimatePresence initial={false} mode="popLayout">
                {filteredPosts.map((post, idx) => (
                  <PostCard 
                    key={post.id} 
                    post={post} 
                    index={idx} 
                    isSaved={savedPostIds.includes(post.id)}
                    onToggleSave={() => handleToggleSave(post.id)}
                  />
                ))}
              </AnimatePresence>

              {filteredPosts.length === 0 && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="py-32 text-center"
                >
                  <div className="w-20 h-20 bg-zinc-900/50 border border-white/5 rounded-full flex items-center justify-center mx-auto mb-6 group">
                    <History className="text-zinc-700 group-hover:text-white transition-colors" size={32} />
                  </div>
                  <h3 className="text-xl font-black italic uppercase text-zinc-400">No Signals Found</h3>
                  <p className="text-[10px] text-zinc-600 font-bold uppercase tracking-widest mt-2">
                    Adjust your frequency or explore other categories.
                  </p>
                </motion.div>
              )}
            </div>
          </div>
        ) : (
          <CommunityVault 
            savedPosts={posts.filter(p => savedPostIds.includes(p.id))} 
            onToggleSave={handleToggleSave}
          />
        )}
      </main>

      {/* High-Contrast Grain / Noise Overlay */}
      <div className="fixed inset-0 pointer-events-none z-[100] opacity-[0.03] mix-blend-overlay">
        <div className="w-full h-full bg-[url('https://grainy-gradients.vercel.app/noise.svg')]" />
      </div>

      {/* Cinematic Environmental Glows */}
      <div className="fixed inset-0 pointer-events-none z-[-1] overflow-hidden">
        <div className="absolute -top-[10%] -right-[10%] w-[50%] h-[50%] bg-[#d4ff00]/5 rounded-full blur-[120px]" />
        <div className="absolute -bottom-[10%] -left-[10%] w-[40%] h-[40%] bg-white/5 rounded-full blur-[100px]" />
      </div>
    </div>
  );
};