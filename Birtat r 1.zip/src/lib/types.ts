export type Language = 'en' | 'am' | 'om';

export interface UserProfile {
  id?: string;
  email?: string;
  phoneNumber?: string;
  password?: string;
  isRegistered?: boolean;
  isPro?: boolean;
  fitnessLevel: 'beginner' | 'intermediate' | 'advanced';
  goal: 'hypertrophy' | 'strength' | 'endurance' | 'fatLoss' | 'discipline';
  weight: number;
  height: number;
  age: number;
  gender: 'male' | 'female';
  onboardingComplete: boolean;
  selfieUrl?: string;
  model3DUrl?: string;
  chest?: number;
  waist?: number;
  thigh?: number;
  streak?: number;
  workoutsCompleted?: number;
}

export type ExerciseCategory = 'Chest' | 'Back' | 'Legs' | 'Shoulders' | 'Arms' | 'Core';
export type EquipmentType = 'Full Gym' | 'Dumbbells' | 'Bodyweight';

export interface Exercise {
  id: string;
  name: string;
  category: ExerciseCategory;
  equipment: EquipmentType;
  videoUrl?: string;
}

export interface WorkoutSet {
  id: string;
  weight: number;
  reps: number;
  rir: number; // Reps In Reserve
  completed: boolean;
  previousWeight?: number;
  previousReps?: number;
}

export interface WorkoutSession {
  id: string;
  date: string;
  workoutName: string;
  exercises: {
    exerciseId: string;
    exerciseName: string;
    sets: WorkoutSet[];
  }[];
  totalVolume: number;
}

export interface WorkoutPlan {
  id: number;
  name: string;
  duration: string;
  intensity: 'High' | 'Extreme' | 'Moderate';
  exercises: {
    name: string;
    sets: number;
    reps: string;
    image: string;
    instruction: string;
  }[];
}

export interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  category: 'Apparel' | 'Equipment' | 'Supplements';
  rating: number;
  description: string;
}

export interface NutritionLog {
  id: string;
  date: string;
  foodName: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  imageUrl?: string;
}