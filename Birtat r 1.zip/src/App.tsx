import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Toaster } from "sonner";
import { LanguageProvider } from "./components/LanguageSwitcher";
import { Navbar } from "./components/layout/Navbar";
import { Sidebar } from "./components/layout/Sidebar";
import { BottomNav } from "./components/layout/BottomNav";
import { MainLayout } from "./components/layout/MainLayout";
import { WorkoutDashboard } from "./components/workout/WorkoutDashboard";
import { WorkoutLogger } from "./components/workout/WorkoutLogger";
import { NutritionDashboard } from "./components/nutrition/NutritionDashboard";
import { Marketplace } from "./components/marketplace/Marketplace";
import { CoachingHub } from "./components/coach/CoachingHub";
import { CommunityFeed } from "./components/community/CommunityFeed";
import { Onboarding } from "./components/onboarding/Onboarding";
import { RegistrationForm } from "./components/onboarding/RegistrationForm";
import { LandingPage } from "./pages/LandingPage";
import { SettingsSheet } from "./components/settings/SettingsSheet";
import { NotificationsSheet } from "./components/notifications/NotificationsSheet";
import { UserProfile } from "./lib/types";

function App() {
  const [activeTab, setActiveTab] = useState("workout");
  const [isLogging, setIsLogging] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isRegistered, setIsRegistered] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showLanding, setShowLanding] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  
  // UI States
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState("profile");

  // Load profile and registration status from local storage
  useEffect(() => {
    const savedProfile = localStorage.getItem("birtat_profile");
    const registrationData = localStorage.getItem("birtat_registration");

    if (savedProfile) {
      const profile = JSON.parse(savedProfile);
      setUserProfile(profile);
      setIsRegistered(true);
      setShowOnboarding(!profile.onboardingComplete);
      setShowLanding(false);
    } else if (registrationData) {
      setIsRegistered(true);
      setShowOnboarding(true);
      setShowLanding(false);
    } else {
      setIsRegistered(false);
      setShowOnboarding(false);
      setShowLanding(true);
    }

    setIsLoading(false);
    document.title = "BIRTAT - Elite Fitness Ecosystem";
  }, []);

  const handleRegistrationSuccess = (data: { email: string; phoneNumber: string; password?: string }) => {
    localStorage.setItem("birtat_registration", JSON.stringify({ ...data, isRegistered: true }));
    setIsRegistered(true);
    setShowOnboarding(true);
    setShowLanding(false);
  };

  const handleOnboardingComplete = (profile: UserProfile) => {
    const registrationData = JSON.parse(localStorage.getItem("birtat_registration") || "{}");
    const fullProfile = { ...profile, ...registrationData, onboardingComplete: true, isPro: true }; 
    setUserProfile(fullProfile);
    setShowOnboarding(false);
    localStorage.setItem("birtat_profile", JSON.stringify(fullProfile));
    localStorage.removeItem("birtat_registration");
  };

  const handleLogout = () => {
    localStorage.removeItem("birtat_profile");
    localStorage.removeItem("birtat_registration");
    setUserProfile(null);
    setIsRegistered(false);
    setShowOnboarding(false);
    setShowLanding(true);
    setIsSettingsOpen(false);
  };

  const openSettings = (tab: string = "profile") => {
    setSettingsTab(tab);
    setIsSettingsOpen(true);
  };

  // Scroll to top on tab change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeTab, isLogging]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center overflow-hidden font-sans text-white">
        <motion.div 
          animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5], rotate: [0, 12, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="w-20 h-20 bg-[#d4ff00] rounded-3xl flex items-center justify-center rotate-12 shadow-[0_0_80px_rgba(212,255,0,0.3)]"
        >
           <span className="text-black text-4xl font-black italic">B</span>
        </motion.div>
      </div>
    );
  }

  const renderContent = () => {
    if (showLanding) {
      return <LandingPage onGetStarted={() => setShowLanding(false)} onLogin={() => setShowLanding(false)} />;
    }

    if (!isRegistered) {
      return <RegistrationForm onSuccess={handleRegistrationSuccess} />;
    }

    if (showOnboarding) {
      return <Onboarding onComplete={handleOnboardingComplete} />;
    }

    if (isLogging) {
      return <WorkoutLogger onFinish={() => setIsLogging(false)} userProfile={userProfile} />;
    }

    switch (activeTab) {
      case "workout":
        return <WorkoutDashboard onStart={() => setIsLogging(true)} userProfile={userProfile} />;
      case "nutrition":
        return <NutritionDashboard userProfile={userProfile} />;
      case "community":
        return <CommunityFeed />;
      case "shop":
        return <Marketplace userProfile={userProfile} />;
      case "coach":
        return <CoachingHub userProfile={userProfile} />;
      default:
        return <WorkoutDashboard onStart={() => setIsLogging(true)} userProfile={userProfile} />;
    }
  };

  const showUI = isRegistered && !showOnboarding && !isLogging && !showLanding;
  const showNavbar = !showLanding && !isLogging;

  return (
    <LanguageProvider>
      <div className="dark min-h-screen bg-[#020202] text-white font-sans selection:bg-[#d4ff00] selection:text-black antialiased overflow-x-hidden">
        <Toaster position="top-center" richColors expand closeButton />
        
        <div className="fixed inset-0 bg-[radial-gradient(circle_at_top_right,rgba(212,255,0,0.05),transparent_40%)] pointer-events-none z-0" />

        {showUI ? (
          <MainLayout
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            userProfile={userProfile}
            onOpenSettings={openSettings}
            onLogout={handleLogout}
            onOpenNotifications={() => setIsNotificationsOpen(true)}
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
                className="min-h-full"
              >
                {renderContent()}
              </motion.div>
            </AnimatePresence>
          </MainLayout>
        ) : (
          <div className="flex flex-col min-h-screen relative">
            {showNavbar && (
              <Navbar 
                userProfile={userProfile} 
                onLogout={handleLogout} 
                onOpenNotifications={() => setIsNotificationsOpen(true)}
                onOpenSettings={openSettings}
                showTabs={false}
              />
            )}
            
            <main className={`flex-1 w-full ${showLanding ? 'max-w-none' : 'max-w-screen-xl'} mx-auto relative transition-all duration-500`}>
              <div className={!showLanding ? "bg-[#050505] min-h-screen border-x border-white/5 shadow-2xl relative" : ""}>
                <AnimatePresence mode="wait">
                  <motion.div
                    key={(showLanding ? "landing" : (isRegistered ? (showOnboarding ? "onboarding" : activeTab) : "registration")) + (isLogging ? "-logging" : "")}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
                    className="min-h-full pb-20 md:pb-12"
                  >
                    {renderContent()}
                  </motion.div>
                </AnimatePresence>
              </div>
            </main>
          </div>
        )}

        {/* Global Sheets */}
        <SettingsSheet 
          isOpen={isSettingsOpen} 
          onClose={() => setIsSettingsOpen(false)} 
          userProfile={userProfile} 
          onLogout={handleLogout} 
          initialTab={settingsTab}
        />
        <NotificationsSheet 
          isOpen={isNotificationsOpen} 
          onClose={() => setIsNotificationsOpen(false)} 
        />
      </div>
    </LanguageProvider>
  );
}

export default App;