import React from 'react';
import { motion } from 'framer-motion';
import { ChevronRight, Zap, Activity, Users, Star, Camera, HardDrive, Shield } from 'lucide-react';
import { useLanguage } from '../components/LanguageSwitcher';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { toast } from 'sonner';

interface LandingPageProps {
  onGetStarted: () => void;
  onLogin?: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted, onLogin }) => {
  const { t } = useLanguage();

  const transformations = [
    { name: 'Abel M.', loss: '-12kg', time: '90 Days', img: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/community-hero-28b9e2f3-1775838956796.webp' },
    { name: 'Sara L.', loss: '+5kg Muscle', time: '60 Days', img: 'https://storage.googleapis.com/dala-prod-public-storage/attachments/6af2f82c-4073-450c-b678-c6d68dff7e08/1775585900488_image.png' },
  ];

  const handleDeviceAccess = async () => {
    try {
      // Request Camera Access
      await navigator.mediaDevices.getUserMedia({ video: true });
      toast.success("Camera access granted for login/verification.");
      
      // Storage access is usually implicitly handled by file inputs or persistent storage API
      if ('storage' in navigator && 'persist' in navigator.storage) {
        await navigator.storage.persist();
      }
      toast.info("Storage access ready for session management.");
      
      if (onLogin) onLogin();
    } catch (err) {
      toast.error("Device access denied. Camera and storage are required for secure login.");
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] overflow-x-hidden">
      {/* Hero Section */}
      <section className="relative h-screen flex flex-col items-center justify-center px-6 text-center">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/f0483e6b-6a1b-41e4-a455-be9ee6d5f7de/landing-hero-87181e62-1775839582460.webp" 
            className="w-full h-full object-cover opacity-40 grayscale" 
            alt="Hero" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-[#050505]/80" />
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative z-10 max-w-sm"
        >
          <div className="w-16 h-16 bg-[#d4ff00] rounded-3xl flex items-center justify-center mx-auto mb-8 rotate-12 shadow-[0_0_50px_rgba(212,255,0,0.5)]">
            <span className="text-black text-3xl font-black italic">B</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-black italic uppercase tracking-tighter text-white mb-6 leading-none">
            {t('landingHeroTitle')}
          </h1>
          <p className="text-white/70 text-sm font-medium mb-12 max-w-xs mx-auto leading-relaxed">
            {t('landingHeroSubtitle')}
          </p>

          <div className="flex flex-col gap-4">
            <Button 
              onClick={onGetStarted}
              className="h-16 bg-[#d4ff00] hover:bg-[#c4eb00] text-black font-black text-xs tracking-[0.2em] rounded-2xl shadow-2xl shadow-[#d4ff00]/20 flex items-center justify-center gap-2"
            >
              {t('getStarted')}
              <ChevronRight size={18} />
            </Button>
            <Button 
              onClick={handleDeviceAccess}
              variant="outline"
              className="h-16 border-white/20 bg-white/5 text-white font-black text-xs tracking-[0.2em] rounded-2xl backdrop-blur-md flex items-center justify-center gap-2"
            >
              <Camera size={18} className="text-[#d4ff00]" />
              {t('alreadyHaveAccount')} {t('login')}
            </Button>
          </div>
          
          <div className="mt-8 flex justify-center gap-4">
             <div className="flex items-center gap-2 text-[8px] font-black text-white/30 uppercase tracking-[0.2em]">
                <Camera size={12} /> Camera Ready
             </div>
             <div className="flex items-center gap-2 text-[8px] font-black text-white/30 uppercase tracking-[0.2em]">
                <HardDrive size={12} /> Storage Access
             </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="absolute bottom-12 flex flex-col items-center gap-2"
        >
          <p className="text-[10px] font-black uppercase tracking-[0.3em] text-white/30">Scroll to explore</p>
          <div className="w-[1px] h-12 bg-gradient-to-b from-[#d4ff00] to-transparent" />
        </motion.div>
      </section>

      {/* Stats Section */}
      <section className="py-24 px-6 border-y border-white/5 bg-[#080808]">
        <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
           <div className="space-y-1">
              <h3 className="text-3xl font-black text-[#d4ff00] italic">10K+</h3>
              <p className="text-[10px] font-black uppercase tracking-widest text-white/40">Athletes</p>
           </div>
           <div className="space-y-1 text-right">
              <h3 className="text-3xl font-black text-[#d4ff00] italic">1M+</h3>
              <p className="text-[10px] font-black uppercase tracking-widest text-white/40">Workouts</p>
           </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 px-6 space-y-12">
        <div className="text-center space-y-2">
           <Badge className="bg-[#d4ff00]/10 text-[#d4ff00] border-none font-black text-[9px] uppercase tracking-widest">Ecosystem</Badge>
           <h2 className="text-3xl font-black italic uppercase tracking-tighter">Everything You Need</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
           {[
             { title: 'AI Coaching', icon: Zap, desc: 'Atlas & Luna guide you 24/7 with personalized adjustments.' },
             { title: '3D Tracking', icon: Activity, desc: 'Visualize your progress with advanced body topology.' },
             { title: 'Local Nutrition', icon: Shield, desc: 'Meal plans optimized for Ethiopian markets and budgets.' },
             { title: 'Elite Community', icon: Users, desc: 'Join the top fitness community in Addis.' },
           ].map((f) => (
             <motion.div 
               key={f.title}
               whileHover={{ y: -4 }}
               className="p-6 bg-secondary/10 rounded-3xl border border-white/5 flex gap-5 items-start"
             >
               <div className="p-3 bg-[#d4ff00] text-black rounded-2xl">
                  <f.icon size={20} />
               </div>
               <div>
                  <h4 className="font-black uppercase italic tracking-tighter">{f.title}</h4>
                  <p className="text-xs text-muted-foreground leading-relaxed mt-1">{f.desc}</p>
               </div>
             </motion.div>
           ))}
        </div>
      </section>

      {/* Transform Section */}
      <section className="py-24 px-6 bg-[#080808] space-y-12">
        <div className="text-center space-y-2">
           <h2 className="text-3xl font-black italic uppercase tracking-tighter text-[#d4ff00]">{t('landingTransformTitle')}</h2>
           <p className="text-xs font-bold text-white/40 uppercase tracking-widest">{t('landingTransformSubtitle')}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
           {transformations.map((t) => (
             <div key={t.name} className="relative h-64 rounded-3xl overflow-hidden group border border-white/5">
                <img src={t.img} className="w-full h-full object-cover" alt={t.name} />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
                <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
                   <div>
                      <h4 className="text-xl font-black italic uppercase">{t.name}</h4>
                      <p className="text-xs font-bold text-[#d4ff00] uppercase">{t.loss} in {t.time}</p>
                   </div>
                   <div className="bg-[#d4ff00] p-2 rounded-lg text-black">
                      <Star size={16} className="fill-black" />
                   </div>
                </div>
             </div>
           ))}
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-32 px-6 text-center bg-gradient-to-t from-[#d4ff00]/10 to-transparent">
         <h2 className="text-4xl font-black italic uppercase tracking-tighter mb-8">READY TO START?</h2>
         <Button 
           onClick={onGetStarted}
           className="h-16 w-full max-w-sm bg-[#d4ff00] text-black font-black text-xs tracking-[0.2em] rounded-2xl shadow-2xl shadow-[#d4ff00]/20"
         >
           JOIN THE ELITE
         </Button>
      </section>
    </div>
  );
};